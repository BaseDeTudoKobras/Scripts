#include <jni.h>

extern "C"
{
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a1(JNIEnv* env)
	{
		//E89B158E4BCF988EBD09EB83F5378E87 teste no aide
		//return env->NewStringUTF("+yJmG28v7grKArAqEVpxBo3dGtXnj04cRj9tJRYX+SMI+x5/iuj+lWhzUa+AR5YQVFXeGhPbmE9mfQeg2iiwdA==");
		
		//D0494FC254D3726BDD50A83B1D5C0EF1 original play
		return env->NewStringUTF("HxjkVMBUiPoxn/B0mZUwOtteIEN6xKeXCyGMDWPinpsxoIZ2DonB39edaKzVVmcMVFXeGhPbmE9mfQeg2iiwdA==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_at32(JNIEnv* env)
	{
		return env->NewStringUTF("LQTpwLyORkbmDGA9eE2yTPHhXNlUZ6VeGSdjnm7e4/A=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp1(JNIEnv* env)
	{
		return env->NewStringUTF("/egKpZ/Jcivquaynr/7O6g==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp2(JNIEnv* env)
	{
		return env->NewStringUTF("GEM8kL3tZKQUdmYu22kFPQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp3(JNIEnv* env)
	{
		return env->NewStringUTF("0vctEbgoXLdl+DFQSeKaDYaeonw4+BdEQeEue2UU1uM=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp4(JNIEnv* env)
	{
		return env->NewStringUTF("LqsHu063qu3cQkM5rJ6PqKHdZiS+VVsiRylkXhHByVuUmGc4iiXe3vHyQ51nPDzx");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp5(JNIEnv* env)
	{
		return env->NewStringUTF("9AFohY3ZR4caGYq4/QnTa2B0kaaTmln3vng9lcR+4tI=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp6(JNIEnv* env)
	{
		return env->NewStringUTF("TyBv9mk2KAMzDRI7BjjztMWjak3aGYWFYVD1JbQ1+kU=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp7(JNIEnv* env)
	{
		return env->NewStringUTF("8Y3xF40SQpYL5tNYHzL1WGnrCHuZP8ACU5uHkEKcJDY=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp8(JNIEnv* env)
	{
		return env->NewStringUTF("BuU+6BI0vJ44sKJhXPG3fwoklCqbKlh9m8G1uLJoaBM=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp9(JNIEnv* env)
	{
		return env->NewStringUTF("yQkdy1OZA5Ko5E4R7XHvJPC0QM7Eu9/httjHcLBSW4E=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp10(JNIEnv* env)
	{
		return env->NewStringUTF("Pnm283Y+YOIJyTh41zj1Gxi6pwME7J4kKzFBj95iSH0=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp11(JNIEnv* env)
	{
		return env->NewStringUTF("mb9EEzz+0OnG44oxciwFZuDSXatnc98uAuN29+py3HA=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp12(JNIEnv* env)
	{
		//libtun2socks.so
		//return env->NewStringUTF("JSRRPD2mjWB0+G0jcZVKvaJHklHqCcLdtH3qHvVVoR8=");
		//lib-kobras-3.so
		return env->NewStringUTF("yQkdy1OZA5Ko5E4R7XHvJPC0QM7Eu9/httjHcLBSW4E=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_tp13(JNIEnv* env)
	{
		return env->NewStringUTF("UFnR/wNGueXZZpTCzny1DZHw+4gvmm9Oqsu3Q+iE9XY=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_ai2(JNIEnv* env)
	{
		return env->NewStringUTF("90QNeAcjWXOcSai/Vc6amrcdSl4qMtD/lN6YT4E9xeZUVd4aE9uYT2Z9B6DaKLB0");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a0(JNIEnv* env)
	{
		return env->NewStringUTF("puRZhqM1gwMjwGRfW33zbwQjlfxqC0PrFBPdc232TktUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a01(JNIEnv* env)
	{
		return env->NewStringUTF("t1GslJZpPUOpEFtE6hNfGn11w3XJagtsQ3zLbbYToUkXeeyq/miV2UpA/30oroHe");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a02(JNIEnv* env)
	{
		return env->NewStringUTF("B+B8lUvIA88RTc+KAj/AqvnUEFUW18J+LA1Xyik//uFRrkeI4J7ERCPtNKRY/6mSL7FOADfiUzCFEfH6c2bCKLbA+Uh1ul+4imncxzG5OS3hU4HIncYCvO1I5ojMMBXdQaGDtRQe4MTlsiLFccNwjQOJ4i9FepFMlDidm+b702oCQscgIUus1ES+4GYa7c+n4Kv9Zl2ar4bHQE9P+9UNHg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a03(JNIEnv* env)
	{
		return env->NewStringUTF("RBhFZ5G45yMTzQPZ+0XMRlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a04(JNIEnv* env)
	{
		return env->NewStringUTF("QoZuX5aFw2ZOqiwo9NypbQmPoyXhww+Cos//V9HpWdE2lkUDEOLXJwVRZcxPvvp7qdMG8KgQbLf0KkCCbTxhx379FcNi5xGs6Y8MH3bfNE2JIr3KJN8k5eHQZpozI3r3VFXeGhPbmE9mfQeg2iiwdA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a05(JNIEnv* env)
	{
		return env->NewStringUTF("9sxcWvQfqk7Y8VQts5yS6lRV3hoT25hPZn0HoNoosHQ=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h1(JNIEnv* env)
	{
		return env->NewStringUTF("+nlvgFKjX2VHPq+Cn74k4+vaM5WcL+astkoaqp7DOt8W4EKkL+22GUDzplCOlJM1VFXeGhPbmE9mfQeg2iiwdA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h2(JNIEnv* env)
	{
		return env->NewStringUTF("wdSekOHwSWqU5fn+SwznZjSoPeoyHmjLQCo/GNocO/IYtMZIv2ZGavy1sOGxR/j6");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h3(JNIEnv* env)
	{
		return env->NewStringUTF("KRUoJgVM95Hr7pUE20c8H7WekwF0CmF8QdfisySUlx5UVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h4(JNIEnv* env)
	{
		return env->NewStringUTF("ANABRkbFPTVhaqsAtPoUg58GfgVb9mgUSMJupKgnQhFeEpbFQO1TyryLSJH+ScsHCY8I478AMNX2hx7h3WsTPKbQnUjh3dpktt3Yv1DXOAhUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h5(JNIEnv* env)
	{
		return env->NewStringUTF("v+pJj6lfOc2HDymW6NGyltzI7kByvcujPKJ89yYZllg=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h6(JNIEnv* env)
	{
		return env->NewStringUTF("U6tuu4QPmptuNudqxXxMbw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h7(JNIEnv* env)
	{
		return env->NewStringUTF("fQkDkEujDzE0pVG+eIyy5gxMi8VQsk/xxof0fMUtHppLn2pJzgT1Tk2ScVvviCKw9PdYUzJT4DSPz5EGTpR34g==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h8(JNIEnv* env)
	{
		return env->NewStringUTF("fg/gqbIyNC5f91Edf6b+L1RV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h9(JNIEnv* env)
	{
		return env->NewStringUTF("/eCB2GyNdDtalwHrHEFTkY13nUEi9t7BOBy9iAQAEHwULpe9ugm2+8b9fkB0fnxl");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h10(JNIEnv* env)
	{
		return env->NewStringUTF("AfLDwUbcUbkAOkcyk5lXYA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h11(JNIEnv* env)
	{
		return env->NewStringUTF("fQkDkEujDzE0pVG+eIyy5gxMi8VQsk/xxof0fMUtHppLn2pJzgT1Tk2ScVvviCKw9PdYUzJT4DSPz5EGTpR34g==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h12(JNIEnv* env)
	{
		return env->NewStringUTF("P0+0BY1Cy7wPDXsrZedw2J/UbuGGn7ToeFnudE9lj2yHbCD7fuAiCWndcfJ4bNZXbwdP5cb1Gi3qzwUs328UjA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h13(JNIEnv* env)
	{
		return env->NewStringUTF("saTLBU2twEIiPzNccimsDg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h14(JNIEnv* env)
	{
		return env->NewStringUTF("/SkEeTRPe3z5x8ZF0uLTybwV0gayhXe5eTnSuflyf0HRf1rjDOJF+mTQVIYTKuE985mKc17jAP0q9yFRTv4xAlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h15(JNIEnv* env)
	{
		return env->NewStringUTF("eo8dBIf29KiAjrV3M6DAG1RV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h16(JNIEnv* env)
	{
		return env->NewStringUTF("/anz3h8vHhzr+EIdBsA5c8p8ibB1txvKk29mCVCd1a13hFGScQ7WGZ3hljgr4AIIhpMnqaTfZvYfUpKU1Gc1WolES+qdTB3hIAjM3SNqkEw23SrpDTeCO6/OsLmMAcYm");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_h17(JNIEnv* env)
	{
		return env->NewStringUTF("7/dD6YxNwWtH29z6lZBHGFRV3hoT25hPZn0HoNoosHQ=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_r1(JNIEnv* env)
	{
		return env->NewStringUTF("6yBCmrb4+w1uDlgxLJPTVjj0EbdOjxrQMfvzN6WmmIY=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_r2(JNIEnv* env)
	{
		return env->NewStringUTF("WaUoCCCOJaDQBz4HiCqTjw==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g1(JNIEnv* env)
	{
		return env->NewStringUTF("MuOGfFx3J1b/3ENTgAhZijHhijEzYIcr28AvLe1OXMSpAQaaBq6K5D4Tj1w2NgyvVFXeGhPbmE9mfQeg2iiwdA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g2(JNIEnv* env)
	{
		return env->NewStringUTF("M+WH4SaQwqr1sKpr4S54MlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g3(JNIEnv* env)
	{
		return env->NewStringUTF("mIoXTwsg2ulFzF9C7j59XfzNpBYAEyDh2pe0Qrf/frAAed6GaG68juzxMFEYDw7R");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g4(JNIEnv* env)
	{
		return env->NewStringUTF("Tbzc5eVkLxHAu2SOlYGavlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g5(JNIEnv* env)
	{
		return env->NewStringUTF("oTbSaYquRKDs9I6hbqkeluHD+BdivaSPdPHuUpJVzQz4g2/gNL+spPUFNePSVqReFjKPIdrlSoj8lI0cg3p8S6n9s8LENaCSAMjS8TgpS5+hTp+kHzOXZMoeMD4ysT3V");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g6(JNIEnv* env)
	{
		return env->NewStringUTF("6812uo+acCmXtt6Xg8lRcw1+qzbftLu/rIcIG7Kn+p4=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g7(JNIEnv* env)
	{
		return env->NewStringUTF("oTbSaYquRKDs9I6hbqkeluHD+BdivaSPdPHuUpJVzQz4g2/gNL+spPUFNePSVqReFjKPIdrlSoj8lI0cg3p8S6n9s8LENaCSAMjS8TgpS5+hTp+kHzOXZMoeMD4ysT3V");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g8(JNIEnv* env)
	{
		return env->NewStringUTF("RRUZ71UVgdv0mwWBNlqV7Nfmfok6ltRTx4/Z/ziZb3s=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g9(JNIEnv* env)
	{
		return env->NewStringUTF("4/lqOSTVRPYD8pVfX5dD4xFk6M2OcC6G8ikAeUh/MNuvFUI6ch6fUXmz0dSkHXBAa0+7JFafKDwh1xUOp1KoTw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g10(JNIEnv* env)
	{
		return env->NewStringUTF("2L2yaOJyMJWCBqL2O92IrckaBULggiaZMkcJkou7mRBUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g11(JNIEnv* env)
	{
		return env->NewStringUTF("uW4SoLSiwgbfEeSIdV+A9WmaXu6ptSNJKi5HZo6/66C7Ye0m3UKptJi9aTqKeG80t91jPNpYQUU6cMQtsCZxVzOpwdq/fPmOjAx2kOvUODvozmGH193nJC4hxJD+sP4nL4LbUu7lPGnAK9cRDbLqo69uHghhTJwzKd1JZnLtk1bJ+VAWrHXHQ+9IRXY3cnUKokRu6PPux0MTw9J9hdBHgQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g12(JNIEnv* env)
	{
		return env->NewStringUTF("5tw8UcEeTIbZWQi+k9VYSQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g13(JNIEnv* env)
	{
		return env->NewStringUTF("Ob2MQdMjCnozNV+u4Fh0R1RV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g14(JNIEnv* env)
	{
		return env->NewStringUTF("jdXYrB0n1C2CLFmc2kk/zkFUIM5b+iS52t+sL0g8d/Pu4rRMjLZoWqXMhwG13Q2E");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g15(JNIEnv* env)
	{
		return env->NewStringUTF("pLgl8tSFHTQ5vnkfSCZaHNqy9dWzkGSBSFsT5nDksx+YFptCO6/eBVnb2Zfcp9Uo");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_g16(JNIEnv* env)
	{
		return env->NewStringUTF("jE4OZJ78Tca5zRrqkn+M0Q==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_u1(JNIEnv* env)
	{
		return env->NewStringUTF("wdSekOHwSWqU5fn+SwznZjSoPeoyHmjLQCo/GNocO/IYtMZIv2ZGavy1sOGxR/j6");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_u2(JNIEnv* env)
	{
		return env->NewStringUTF("ibujuTr94eVYxbrqKfC2napm+nL1xRTnLmpQtQVAJ+EyUVnR9VNeSd6dHJ22witY");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_u3(JNIEnv* env)
	{
		return env->NewStringUTF("TQ8A9S28h8ZJtGQOLZbQ8rIwU8UW2dmrSfe5y3AwDOsoebKh68tEqh4VPA9TBkxm");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_u4(JNIEnv* env)
	{
		return env->NewStringUTF("ea9cyNjyC6iasJhieCNdHYRuC2rMx+tKUkVaqLvDUXlUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_u5(JNIEnv* env)
	{
		return env->NewStringUTF("3+gHGZmcermgHCduYDbuH1RV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_u6(JNIEnv* env)
	{
		return env->NewStringUTF("GN2PY7dl6KF5e/SG9fzbkybHfGIBKQSTlyEl8dna6xXXo81JS+YvbtYoWtij7JNWeiL7lVDUin4NQB5xoAxhqvUKtU6WSa/hHalXwXvx3YdVtNVWHkuYRmc25KBH7RI1ZoxZ2Td/XvpgYdkA8o7bZg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_u7(JNIEnv* env)
	{
		return env->NewStringUTF("jE4OZJ78Tca5zRrqkn+M0Q==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a271(JNIEnv* env)
	{
		return env->NewStringUTF("ktkwBXDMAqIkJVhm/JoACCe9YdWwR+FalOJw/xfuR4k=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_ab0(JNIEnv* env)
	{
		return env->NewStringUTF("ZTFUOYFYsvkZGXT7KaOVqFRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_ab01(JNIEnv* env)
	{
		return env->NewStringUTF("LaWvlQo0u0ErDpjVdPUUdFRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_ab03(JNIEnv* env)
	{
		return env->NewStringUTF("RrFLKPnb07U2yF1ZPGF24kzoNCO6BWJI6q6QVMWOTWlA/OV9JXxl5fxK44SMtLmQQFBrUQaHE4Ehg5yaujTP37Jyu8ksEL6Ht1xWBQU01b5uwTwMdXixAnK3+VPegqRN");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a2(JNIEnv* env)
	{
		return env->NewStringUTF("wAW3QjI8sdcmRqmzsGwMeYU5NQHUJGLooGP/pWIJouBUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a3(JNIEnv* env)
	{
		return env->NewStringUTF("UgHduhlBhlmY6zQOYgHqLhnRfyH+DcBFsf+ZS+7vwmfhMgskRsBNB1Gv0j/dc235u5CF+oLj0QCG8NrP+STzXA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a4(JNIEnv* env)
	{
		return env->NewStringUTF("y3GCtxxgFzOXFtp/Qm4s172hatJzX4cacDt0MNfXOoE=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a5(JNIEnv* env)
	{
		return env->NewStringUTF("ghA5/GFgeJUbA3KMQUbZYqN1+A2n9gdn+rX7ko6C9WI=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a6(JNIEnv* env)
	{
		return env->NewStringUTF("nMGwaxZZsT54T0bHvKRoNH1D9lzREUDV7wf/4dmdD/9ANslVvDeV2wnPVUCAsVWB0Ch0kaKTTq6euLUCtuAlRWQ1rvK7gNGp/19g14fmUkpUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a7(JNIEnv* env)
	{
		return env->NewStringUTF("pE98O+6TtehHXEtHEhNHaxvkLPUS9+2Okf1gI6coC1w=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a8(JNIEnv* env)
	{
		return env->NewStringUTF("GUF0wvD78CpVaRuJFhELupzP7W3NLcwMBYWerXDCJfk7fLRjmK5dog5O+9fYPn11VFXeGhPbmE9mfQeg2iiwdA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a9(JNIEnv* env)
	{
		return env->NewStringUTF("LqE7DbYeWfOZNor+o50shf54jh8ylzJYO7VYRbJLLiA=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_ar3(JNIEnv* env)
	{
		return env->NewStringUTF("DcfmYuAPowea73ObiyjWZJDsm8DMgKC3hwzgX1ot+FNUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_as3(JNIEnv* env)
	{
		return env->NewStringUTF("vYV2cQgMcAzDxqo4c3Mf/C1M/a5X8WgP4F+Ng0AMR2pjpWZ+rQ2sQUVn0wI9TH5FcV7X3afvGR7AMcuUD+TetA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_at3(JNIEnv* env)
	{
		return env->NewStringUTF("XtZC75yONWCFmgJlucfPdA==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a10(JNIEnv* env)
	{
		return env->NewStringUTF("AgWqhc/cVqMzDNW75JCFSBGL2N6mnol/cM/OTfjAWu+ZNl14O9EG8miIrKJrMujY");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a11(JNIEnv* env)
	{
		return env->NewStringUTF("XILVdZp6970va+ZkbuE+yJCjbuMNSS+9tEVDN9cJE5k=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a12(JNIEnv* env)
	{
		return env->NewStringUTF("JXDRLPSJfq1FlsJ7SYKUbN8eKxH7iPmccNnAmYpm3VLdyaOzmRO2BjRHUttRPm7XIyz3GTelFlR6i7tJ+lzQrI1RyK3cECYzJUe+1t8+Kpw=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a13(JNIEnv* env)
	{
		return env->NewStringUTF("KRFO2zrszNb7rere5jG+5Q==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a14(JNIEnv* env)
	{
		return env->NewStringUTF("aWhBFRyA1m595biefQSBclRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a15(JNIEnv* env)
	{
		return env->NewStringUTF("c2eC+aSe+GPi1btIj3nZQlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a16(JNIEnv* env)
	{
		return env->NewStringUTF("8zGZ6ibJIIw6IRcrRwn3nVRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a17(JNIEnv* env)
	{
		return env->NewStringUTF("gIQolNj3E1XFa764y8t7mw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_Kobras_a63(JNIEnv* env)
	{
		return env->NewStringUTF("0tN7qMRdS077X+P/ScOXmunQ9oYjr/gok53+z99NMMhbDxrjW8T9IHxEArA2LETVI6Zlz9mDyto/S1Ubnq0xJNgSbQxEezGjVRE1YQsTioM=");
	}
}
