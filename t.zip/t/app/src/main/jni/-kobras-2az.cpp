#include <string.h>
#include <jni.h>

extern "C"
{
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a1(JNIEnv* env)
	{
		return env->NewStringUTF("spcQz+VGHUWP0baSLPVu4FRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a2(JNIEnv* env)
	{
		return env->NewStringUTF("BwUTNl9N5Ecd3ZA1wc1w1g==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a3(JNIEnv* env)
	{
		return env->NewStringUTF("3DUb4KpSz3WvaocGBK3A3K3B+D/A/JJbOJyBf+W/zqo=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a4(JNIEnv* env)
	{
		return env->NewStringUTF("aww5Ssu1n62i3DYCQQ4A/VRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a5(JNIEnv* env)
	{
		return env->NewStringUTF("fw+OQRzSitl43vbhI4hejg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a6(JNIEnv* env)
	{
		return env->NewStringUTF("QhyhK6O//QJTthnM7bLwAg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a7(JNIEnv* env)
	{
		return env->NewStringUTF("HawMdB58a3JQlZiH6j/lAw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a8(JNIEnv* env)
	{
		return env->NewStringUTF("P0oW5Q56QsQ6CIYQwI5r5AwBB8dN7DK5nN7ISrymdO0=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a9(JNIEnv* env)
	{
		return env->NewStringUTF("wJ6w252Z2xVU9DpeSsqI4VRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a10(JNIEnv* env)
	{
		return env->NewStringUTF("0M291y+1SEAGkoDvuIMP6lRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a11(JNIEnv* env)
	{
		return env->NewStringUTF("yQg0Bkeu0bvyebtZXvYSoy4OOokceE3GovlrR3v3Gso=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a12(JNIEnv* env)
	{
		return env->NewStringUTF("6CCwc9sBcSuqWpcS901T2JRkCfbLySqnI72wxzO0A2dUVd4aE9uYT2Z9B6DaKLB0");
	}
	
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a13(JNIEnv* env)
	{
		return env->NewStringUTF("niw/wgOBjeUoIaYtmOrPSg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a14(JNIEnv* env)
	{
		return env->NewStringUTF("HI+oPMZYg5V+h9uISBRCZHMbHVl3iWZGZXukSCRlTKtUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a15(JNIEnv* env)
	{
		return env->NewStringUTF("pd0mMPqz5mt7+A8IwxH97VRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a16(JNIEnv* env)
	{
		return env->NewStringUTF("hbXrDwBXKM1rnfE7268a9lRV3hoT25hPZn0HoNoosHQ=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a17(JNIEnv* env)
	{
		return env->NewStringUTF("bzwvb5/nGvm5eRn4aDBr9Q==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a18(JNIEnv* env)
	{
		return env->NewStringUTF("4wiTrFURxw3DLn/0i/V6xw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a19(JNIEnv* env)
	{
		return env->NewStringUTF("9Fqhn0evvQcrX3/coB6dGg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a20(JNIEnv* env)
	{
		return env->NewStringUTF("x7GRdri+gaT06tiCRNthYMwIkhF36eyPMj4KAMnE3DOKhwGz1L53a8EWPSJPjs9j");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a21(JNIEnv* env)
	{
		return env->NewStringUTF("tzPOON1zmD2ZeURguDAaIQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a22(JNIEnv* env)
	{
		return env->NewStringUTF("oI8TstnZJ2WxwyRbeVBX9oIzTVjZEb6WG1d09prUBYc=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a23(JNIEnv* env)
	{
		return env->NewStringUTF("QoZuX5aFw2ZOqiwo9NypbQmPoyXhww+Cos//V9HpWdE2lkUDEOLXJwVRZcxPvvp7qdMG8KgQbLf0KkCCbTxhx379FcNi5xGs6Y8MH3bfNE2JIr3KJN8k5eHQZpozI3r3VFXeGhPbmE9mfQeg2iiwdA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a24(JNIEnv* env)
	{
		return env->NewStringUTF("qujAS8e1YgDaKha4OJ9uJw==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a25(JNIEnv* env)
	{
		return env->NewStringUTF("Txc8d26ciTTapCcUHOHUxzImH1vopRw1abjItY5+efDxxF1oezhq8LpbexpoF9MpIjTdHimNq6em9rpXS8/Y6D3tTedpt3pTpctWkvQS2IynNDcr4YOU//0ip93rfaTXdvTu54OKoc/4HprHCNztJA==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a33(JNIEnv* env)
	{
		return env->NewStringUTF("9sxcWvQfqk7Y8VQts5yS6lRV3hoT25hPZn0HoNoosHQ=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a35(JNIEnv* env)
	{
		return env->NewStringUTF("Bg8JNg+dezJ4/9cCkEKychgZa7ZG9ZF2w1C+pVeIzls/iiSPNyhBTcCw2pSxbjI1");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a36(JNIEnv* env)
	{
		return env->NewStringUTF("GmMiSxqRj0FjC1iSISXOCMaMovtzXwpPjskJJpnLhLJuIS7J8D0sdnvsgFdoY/E0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a37(JNIEnv* env)
	{
		return env->NewStringUTF("alyWHiur8BweEE3ul0tiI+9WEyrYSJuCAy/8MaBJeBk9WdVFIL8r1HRLz8c/hlqpa76UUoDtIvqzzETxPm7mFlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a38(JNIEnv* env)
	{
		return env->NewStringUTF("BTMy1uXEC98yvZePXX+Mzjg1xGQa/JSpzwhOL0P8jKBUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a39(JNIEnv* env)
	{
		return env->NewStringUTF("+wPJC3o8ImhnMMwfyUN7xKdqfIGEbWVprbCZfdvKyVLYibFuakY5d4WKW5cBKhGO7zf5ZkSSbPsw6yFG7/qQ62HK2682ZBtZILS6aTQ4WK0=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a40(JNIEnv* env)
	{
		return env->NewStringUTF("FjqhMrHhi6tvNVFu4usmnZ/XQzymoKiT1/bjLHzJUWQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a41(JNIEnv* env)
	{
		return env->NewStringUTF("Az0PdxSROYAvki97kLrn3uX9Te5Dxg8MkRjWlRghK0gFSo0EZiOSeIVSbWbxYL3nbOLymQfepBegGGdCQOhlNkmIlYtNvf9FVuPxJI/ia6bdfKceS6ydaLa/AXCYJzBfqb5nHaaH4oQ1Z71EAk+ucZQ3lWnHunXoOYGv5f/waj62H7L2/tMXTllaW6KJeQ0JbJZMZoXyhbPi77Deu3F2sYKAkIaVOAVUxJCetTLrxW+VyS9W5mGGk7wy8/Md9qXTc02IYEI+6KclFY70zsvRgQ59M9f8CqNK7HrWdzJoFDsxq0s3GfGV9tMfnLm86mrSXFqeV2euBE2vxVnBZbHyCes2JYiOwgRP5ouv9mkMrQLy3saj1x9ipXd6qHcnenV7rk9FQkhoA5UPtj1hU22yY+HuKGTNr928i1lcSQVI5dxnHS4BHOhIj5VBztCcxQUOX57SUR/f9+inTb110NwATbeKD8nsz65ZTlbwe/Byjo4pK07wEDoGoZ0NVrjiHDmWdr9DUUCqJ3gsuxu+5Q6OF9bkhsYEpIjDpy8yyC4bX6Qx2qQWSYHbsGYmBmzUPhE3YBU3qNqyEowt5Q9CdIp0FSQToJZg2MITl2iTRaottxHp5Ov2WLVwxMBOMG2UR//eJwegFbcTmB3K36bOHJIhCkvFEcgUUVbMBGLDR+m7LcabyAprM2E7gLjvtOMeEdmi8wWz0f2dGafzNHpFsqZQ8anJOOjLEHpJBXUCw6Gr4FEvd4QCUYZL9czTBraYlz1bf1usygPDuq3bk1TuglUws5mKcUCKRiw8v3H6yZbiQzbHBnr9paSgzZhqYwjory+1YPyu5JIpOcE5d/ZivaTL3S6Wi6VLpdZycDm8vLa6r6GGQ/zHbRAOc4s80kCHaCukoSDZ1uPugN4L0svbqPs9gWv83xpnuNl/qAdpXWdZk02HNl71b4jpSrEVnPAQKXPvyrB3Jo7qhRsa1oN+gPdjE9Kd34MIMqQL4WqK7Cc9jTuZeZK12fvyrKe6qZ4wo1BMntY7YuF1V0oh3xD+EAK0ZHp2i5BavqPmFBTiyK7XQ+hLOoaN+YkSHNpC6TL1dtk2xLTlbVGKpEIhFU0GJ+UUUuCWkpY4X26F/439+85ZJFIFjM6YeGUKGuT3mZA+Br4fntdhOWlHfa5T4tqHNbCsUjeWrB5a4Wn+TDRMcUJpESGGLQpu/yjnBoy1TYX8uy4u9wOqlZTSZyKcDxuPFbKc1WCQ85Wpbt4YPZyKflZI1VuvvtlRwCrx/u1A4x8DTVcCnp2jL7jl0ebLpdPk+uhFIuyGv6pBslFsuCcLv+dYH2Bvax9p1vm+1rvMm3mC/XE3JMfSe4QkWNuHshJ6p2a6YPGWLp5EHZed7YJFbivWh4mXW17k+jy4Xr7VVeCsQ897yM++v7Z6m3JIRmnZvP4IOGSdHl6uILxHh1RHnb9vbZmENpZ2x+WLpeHWpX7r9mUF1/pZO9wAXmd0RK9uHSI0nWobu61eCGVgChx4TnMWPhsYF9+YYwMQ/KzMyfTm0II5HymjkumDj5OhP/lRGXAdZs25A2YHI8IwNYiTeulRcMk9eL6wXWT6pz1UWzgJ6e/QAoyZXClgZLCVyVaX69zxLVRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a46(JNIEnv* env)
	{
		return env->NewStringUTF("AYZWjzxgU9lDjh3jsNdhT2HE2YQMPOs8cCLs+QsdrMFXm8K1dZCPje9XsGMaB7md");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a47(JNIEnv* env)
	{
		return env->NewStringUTF("/MGjgOmq6y/TsSpvjSJaiw==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a136(JNIEnv* env)
	{
		return env->NewStringUTF("Xl8mwZ3CVkz4eaHSCRcuN2wL/GCjItJ4E02ZoK2sBIhfGd0C/Hoee6Z0GGbXxmbM");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a137(JNIEnv* env)
	{
		return env->NewStringUTF("qFNCCCWqcrbRQ6+yxVQ066cz5egurEJ28bNp9NFMjl9rdrPeMAzz9NaLIDigW56mjKoZDSCau+KTddc12XJIIqc96g3zrLZCUxg+kalfX8E/fN9baQ2dPqvewiqGFbf4");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a138(JNIEnv* env)
	{
		return env->NewStringUTF("97Rh/dZHwki+7/YZNI272705Jcm5aJUrv/uKxycoGY9ZnA4q/84ANB5e0Dg9eqbP");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a139(JNIEnv* env)
	{
		return env->NewStringUTF("MkC3fiHRcCU4rRgW4ABih7b3BdV8o3wVVJ6sv6f+Gbg1FmEJa5SrjGF87/Lck6WX");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_az_a140(JNIEnv* env)
	{
		return env->NewStringUTF("L9tyDrKTkjyurO1KIroaQiCzAlZJseQ7YapbyqYY8NZz18oI0EylVWWHJqp3zPwDn26CASGaFc1DHIQtHuEbVyeFyCdCluLPfMb6Xqxe7OHHNtlRN7+yag9uXm1ZfAj2");
	}
}
