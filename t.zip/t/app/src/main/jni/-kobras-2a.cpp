#include <jni.h>

extern "C"
{
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_z1(JNIEnv* env)
	{
		return env->NewStringUTF("DAPfJiQNA4X51Tqz4mI+c1RV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_z2(JNIEnv* env)
	{
		return env->NewStringUTF("rSIrJuLQGzHkEJCMVa5BylRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_z3(JNIEnv* env)
	{
		return env->NewStringUTF("BChUUbNtF1+MqnO6JvJk+1RV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_z4(JNIEnv* env)
	{
		return env->NewStringUTF("pGw0qRvRRvT2jTJH2HsZdsYfHUf5Za3wwFFRlV7q5Fw=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_z5(JNIEnv* env)
	{
		return env->NewStringUTF("jRB5HqicS1XywgmR5jR4JyKvTFWri7iChGg3udu9kjw=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_z6(JNIEnv* env)
	{
		return env->NewStringUTF("Y4zF3y67/JtfnJBQC7nRouO/kzrK5XW0P2diI4B15qE=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_z7(JNIEnv* env)
	{
		return env->NewStringUTF("O695vf8ZyQAsGOef7gMUHL0B1Z4vMIhBxQe2VZ+8Q3g=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_z8(JNIEnv* env)
	{
		return env->NewStringUTF("bAsBQfutf9gsP+j8lVkTf25C0sThv6V7mAHSbUk069U=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_z9(JNIEnv* env)
	{
		return env->NewStringUTF("nj1yNfv3I1k9qAebNn+PRA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_z10(JNIEnv* env)
	{
		return env->NewStringUTF("pNTjyqycc6tCofBMAdQx+g==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_wy(JNIEnv* env)
	{
		return env->NewStringUTF("WnisTDJGAQL3NP8tsPDcZQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_wy2(JNIEnv* env)
	{
		return env->NewStringUTF("Nb/iKtQyIF6XgnAwCitNzw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_wy3(JNIEnv* env)
	{
		return env->NewStringUTF("RIcjdu7vbqHo1tFwpJB4TlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_wy4(JNIEnv* env)
	{
		return env->NewStringUTF("TSn7k018OsNy3NPnmSccZFRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_wy5(JNIEnv* env)
	{
		return env->NewStringUTF("C8+wHwZeENGFUmt/MqaWxg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_we(JNIEnv* env)
	{
		return env->NewStringUTF("fsFmAwY3Epqf1hX2PJ2IRw==");
	}
	/*JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_bu11(JNIEnv* env)
	{
		return env->NewStringUTF("5tjZq+HSEBvK9iDpCLAifNnhsEpN+lbapU8RhbvRHkjiHnd0Ng8c7sbXqXNkTlTtx+YjuGUlNn0nXzGcTly5f1RV3hoT25hPZn0HoNoosHQ=");
	}*/
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a10r(JNIEnv* env)
	{
		return env->NewStringUTF("hxclVBERigD95tyOOU576kN+AqP06b2E5TFM9WqCsq14lNHcKrH7pI62yt+qWxHK");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a60(JNIEnv* env)
	{
		return env->NewStringUTF("aJwx80ZIbtuDM9w/6+uM5+MBF9e4y/J+r3AkyV0W1rswpNLaa2glCub/gf57nVYSoRNpzv+fKDOdfy1hdpoUl5rb0GyPbqT8x/ChE1jKahc=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a62(JNIEnv* env)
	{
		return env->NewStringUTF("AAz7XsN2Ux6nHiN5Fx7gWFRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a63(JNIEnv* env)
	{
		return env->NewStringUTF("ZKAQH7N3M8D3v/QxohmompnAxX/s3RXMysqRFfiyilSiGCk70+OT6R60Ygvs+hxpXePrq6056n8yDZXpKP19TYJepigNIqh5t2KSA1yWIoA=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a69r(JNIEnv* env)
	{
		return env->NewStringUTF("TA2ilsZ0wHzP6lZQ9cdKnvo4lgVpbxxLaAxi30DPc5Lq76VPFagcmeYKXw3mYrVanNPTmb1WfnPRnE9ld7h4DmbvfOvsLXWZ7MrpK1L6oWA=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a71r(JNIEnv* env)
	{
		return env->NewStringUTF("t9sd7+psSEOZbtJAkOx0jFRV3hoT25hPZn0HoNoosHQ=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_i14(JNIEnv* env)
	{
		return env->NewStringUTF("hxVOzdwOtqsKzKUdxs3gtc6Zk7TrIC0G8YrE0rCLTKr1i8OZh4ODlDX//WPlKY7b");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_p1(JNIEnv* env)
	{
		return env->NewStringUTF("WawXxrkzo7ovzjdeYlY4tA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_p2(JNIEnv* env)
	{
		return env->NewStringUTF("raOiO8r9ZDGxvBrxw2J/Nw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_p3(JNIEnv* env)
	{
		return env->NewStringUTF("TnGNqLuPT4pTn4vZv7t6+g==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_p4(JNIEnv* env)
	{
		return env->NewStringUTF("UElH3BDYRLCNvHPRKE5CGQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_p5(JNIEnv* env)
	{
		return env->NewStringUTF("glienKAKIH5Qy017epvBCQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_p6(JNIEnv* env)
	{
		return env->NewStringUTF("AV3FJNkNV22OXxd1ow5XJA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_p7(JNIEnv* env)
	{
		return env->NewStringUTF("sqcV90WG7mmnjHFa5eCPCg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_p8(JNIEnv* env)
	{
		return env->NewStringUTF("TfKUUU6qb83xxzMdKoCZHg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_p9(JNIEnv* env)
	{
		return env->NewStringUTF("kiIQLFwxRlaBwTaOXv0s0QEXEfFiNLe/ZOYF35/tKgvJot+x66Pb/uw2N7p4ucmqLKBDEnPQVf8WANhyhhG+DonudwQGPj5/W89eWvhevGQ=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a1(JNIEnv* env)
	{
		return env->NewStringUTF("nG7fkdJouUvz06LMOUyqU1RV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a2(JNIEnv* env)
	{
		return env->NewStringUTF("Q1PywlWks79tPVGvJMIHAFRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a3(JNIEnv* env)
	{
		return env->NewStringUTF("cCAL91zxH9OSARF/TeHsWFRV3hoT25hPZn0HoNoosHQ=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a19(JNIEnv* env)
	{
		return env->NewStringUTF("U1oPC1bWHwzZfgq9elx4P4vICu6ca+xxCpZrRBcUa+A=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a23(JNIEnv* env)
	{
		return env->NewStringUTF("Qtpc1cG2FZp2DuYw+qTAhlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a24(JNIEnv* env)
	{
		return env->NewStringUTF("469U2D0S+43scJLS/jS3AA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a25(JNIEnv* env)
	{
		return env->NewStringUTF("nS7VfqcdJym8Enl+w8vExwHtsxnnOHQcxUQEi0wV3/nIdd/yKjg2eYlaNMQH47duotbgz0t8pPeHFhhxrY73W23eMoYskV8iRYH3HIzzfKHHOSA63CX9SPmm0aWcT/+G/aq65pR0wv1FIWnwTx5wdA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a26(JNIEnv* env)
	{
		return env->NewStringUTF("gmfpTuUnjoBgnMqngm+/cQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a2z6(JNIEnv* env)
	{
		return env->NewStringUTF("QH++f1lrmfVxIQUac1x91g==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a2v6(JNIEnv* env)
	{
		return env->NewStringUTF("B+29hwlyF65Zzzqs+YZ+Iw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a27(JNIEnv* env)
	{
		return env->NewStringUTF("LwkqskUioQYKxgzVDI+aTQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a28(JNIEnv* env)
	{
		return env->NewStringUTF("MCMFJWhYNQPEvjW+Dxl+1Q==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a29(JNIEnv* env)
	{
		return env->NewStringUTF("za0cwUZjqcVBT4GfhcWE6A==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a30(JNIEnv* env)
	{
		return env->NewStringUTF("5GlAjE5l0bM/WqiW2k0DMw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a31(JNIEnv* env)
	{
		return env->NewStringUTF("rRJwY/V9M/YNIywz2QQNZw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a32(JNIEnv* env)
	{
		return env->NewStringUTF("FddgEcPnPWLf7ZSAPKR61g==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a33(JNIEnv* env)
	{
		return env->NewStringUTF("IT48qprR5JMKBKJ7t3KVQg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a34(JNIEnv* env)
	{
		return env->NewStringUTF("pmq6XjW8YOkuDqvfODX38g==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a35(JNIEnv* env)
	{
		return env->NewStringUTF("BTdwSnSs7bQp5Es19otPtA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a36(JNIEnv* env)
	{
		return env->NewStringUTF("sLcw2wTKZnxeB4MBnBUewQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a37(JNIEnv* env)
	{
		return env->NewStringUTF("YORNkhIEPrGTgGB7di1tL1r0dx1X1bwc2RoYMaXiDcQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a38(JNIEnv* env)
	{
		return env->NewStringUTF("3EV5vHR8B56ZPOEkxE/CB1RV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a39(JNIEnv* env)
	{
		return env->NewStringUTF("9sxcWvQfqk7Y8VQts5yS6lRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a40(JNIEnv* env)
	{
		return env->NewStringUTF("wGLMbVtLQUD84VIeKujaK1uQcDx7h/BIh8fMNtGzrbs=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a41(JNIEnv* env)
	{
		return env->NewStringUTF("taH5LWIJKG5wEx2Kh8U0OntsjpW8oKnKcJNG/hQlNmY=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a42(JNIEnv* env)
	{
		return env->NewStringUTF("+la1vDozlsG3XLgdQYChxJKX2PA85350YjCWA8jmqttPClV3nns8mfIUqy0Z9sc/NmSGcdYMCbBbKfArWR9cNg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a43(JNIEnv* env)
	{
		return env->NewStringUTF("PZXvi+VydbRF4Y5LX4u85QsedXhnpEiFiQHfon9678XCXTqWzO+weoO5IImAtNwy");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a44(JNIEnv* env)
	{
		return env->NewStringUTF("azpAKsDq2NnPLE6R+2MWYIFUvv3sbc8xuZFT1My5SUQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a45(JNIEnv* env)
	{
		return env->NewStringUTF("fOrahibul57E1zBCwMRpiI1T7TNc1WkC0tk1lxNxxCg=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a46(JNIEnv* env)
	{
		return env->NewStringUTF("3ySf+tVL8uKsgR8IU7u/A0jIzXwcmh2V1dKp/5HE29E=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a47(JNIEnv* env)
	{
		return env->NewStringUTF("ZSLL6l09c8ShYinYh88YsFRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a48(JNIEnv* env)
	{
		return env->NewStringUTF("j1B8zzFp4zcKmLU4DWrNAg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a49(JNIEnv* env)
	{
		return env->NewStringUTF("cfx3AOo82ekxTQl6mvDkAA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a50(JNIEnv* env)
	{
		return env->NewStringUTF("0N5YhpLsUI5cVGvFv+aoHw==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a51(JNIEnv* env)
	{
		return env->NewStringUTF("yWGhdqrwOkv86eesjHmmpA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a52(JNIEnv* env)
	{
		return env->NewStringUTF("CuI/lJESGZ4Pjwdf8ehVXw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a53(JNIEnv* env)
	{
		return env->NewStringUTF("VLAPA+XDfvgs6XPfqrmFyA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a54(JNIEnv* env)
	{
		return env->NewStringUTF("AaYo2fQThoLZ7OC/94+fqS6wLbDx+Q9DShl6511IEABUVd4aE9uYT2Z9B6DaKLB0");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a55(JNIEnv* env)
	{
		return env->NewStringUTF("QRCIfLpchpT1R+Eq/sSG8Q==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a56(JNIEnv* env)
	{
		return env->NewStringUTF("es5V7kAXlw38+IDBGG0K1g==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a57(JNIEnv* env)
	{
		return env->NewStringUTF("wxatVXqClyTqSF3wqZopuHGKT3CcDRBooFL175CpQHw1/mKdwAkSjqNjUY53/JsburbFvAWOW5Wtb8vysAVR/fLgIlOrA8kM1JBvRGr87FxUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a58(JNIEnv* env)
	{
		return env->NewStringUTF("0PmdYPuHZ/kAyuBXQZ8YbkTbWLp/OCwE+HDGUvqoUtYCoSIMZCe/9SU1CsXKLwUaIxzltgBq6iVQQDRvsDFFnU6nZZddMihkU1HjiC4uLvA=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a59(JNIEnv* env)
	{
		return env->NewStringUTF("1HRQotOEXTYqJfOUYXzmdClN+4AnDKiaOxZtg/cwrEo=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a61(JNIEnv* env)
	{
		return env->NewStringUTF("+JII4ve3AGC34MT9SCMziVNr6byMZL5mYA3OZuY0oJE=");
	}
	
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a64(JNIEnv* env)
	{
		return env->NewStringUTF("hfbTPKlr4ZRN6iZ410/hZtvYoE1c6xpzixUPRSh32Gc=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a65(JNIEnv* env)
	{
		return env->NewStringUTF("SNhtz5300CEal4ULBtpQPXOP+SIuNiULpb3WqsOTyExUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a66(JNIEnv* env)
	{
		return env->NewStringUTF("GrG4g3D+SN/oSUs36B5tkA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a67(JNIEnv* env)
	{
		return env->NewStringUTF("coFRCH0SujR2eMFy9LiIWA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a68(JNIEnv* env)
	{
		return env->NewStringUTF("hxp5FTl/E+J0vd/a3QRUpw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a69(JNIEnv* env)
	{
		return env->NewStringUTF("W6jPh+KHFdzSDyv2qtpB2dy5mwZgpo5znM/SNrLh6ms=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a70(JNIEnv* env)
	{
		return env->NewStringUTF("ubPJhpSguxLqCo/nnQbUSg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a71(JNIEnv* env)
	{
		return env->NewStringUTF("8yET/lcUfH6cNGwBYGGP4w==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a72(JNIEnv* env)
	{
		return env->NewStringUTF("IiUo0ct80ghtGf9N8QdFC1RV3hoT25hPZn0HoNoosHQ=");
	}
	
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a73(JNIEnv* env)
	{
		return env->NewStringUTF("IYtwgu/g1VRQF2LPmdyyqFRdZBl5OMipbcjwOlkSd6VUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a74(JNIEnv* env)
	{
		return env->NewStringUTF("GB20C9eLNxaWN1NuAlRgwZkHRdNgAspSrv9DCI/iyhc=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a75(JNIEnv* env)
	{
		return env->NewStringUTF("ztPTsc3cp/pL1/1bAO5QwFRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a76(JNIEnv* env)
	{
		return env->NewStringUTF("mhWm9QMOElqpsJXsCL3aNIhOAU8VANf33/cVEJFx+2A=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a77(JNIEnv* env)
	{
		return env->NewStringUTF("Qbb6BTjVxY29pZNm62kbLEvy/EiMb68nUdlzcr776Vk=");
	}
	
	
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a78(JNIEnv* env)
	{
		return env->NewStringUTF("TnPzCt00CyvcFDwQAijyFwJkneMIC41Xepi8ATpA+Bk=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a79(JNIEnv* env)
	{
		return env->NewStringUTF("aE9YHyMH3tqf1nvBYM2lZoBUN2NJV2tN04LYX8bNdsjDQ4uLkHRlOmhfEVrBbSJT");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a80(JNIEnv* env)
	{
		return env->NewStringUTF("3HubMjZSKYf8HFKYBv1/lVRV3hoT25hPZn0HoNoosHQ=");
	}
	
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a82(JNIEnv* env)
	{
		return env->NewStringUTF("NaYKiFehOv/AJXefN+lElg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a83(JNIEnv* env)
	{
		return env->NewStringUTF("+clETCM2UdAj+t6VlEsbrFRV3hoT25hPZn0HoNoosHQ=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_wq1(JNIEnv* env)
	{
		return env->NewStringUTF("JgWvoqkRvOSsgrWIxDVHNsgGPRcj0wgndsTxdc5QDuk=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_wq2(JNIEnv* env)
	{
		return env->NewStringUTF("1EkyOfrVFnGseTCV2UL6NlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_wq3(JNIEnv* env)
	{
		return env->NewStringUTF("HzHccTYywUdvpKAgGBe+hFRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_wq4(JNIEnv* env)
	{
		return env->NewStringUTF("+rcaq8PzTSXMXVr3X7qna1RV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_wq5(JNIEnv* env)
	{
		return env->NewStringUTF("NB4wOm8Re7XJK7S8iPo6v1RV3hoT25hPZn0HoNoosHQ=");
	}
	
	
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a84(JNIEnv* env)
	{
		return env->NewStringUTF("cMMxtlgVwXJG6BIvUryBK2LlSrbv+42758bjq7AJXS0=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a85(JNIEnv* env)
	{
		return env->NewStringUTF("MYQdKxebrq6kfrQRVRCA2VRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a86(JNIEnv* env)
	{
		return env->NewStringUTF("X82bosNsZiOW2hrl75uL4lRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a87(JNIEnv* env)
	{
		return env->NewStringUTF("/MGjgOmq6y/TsSpvjSJaiw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a88(JNIEnv* env)
	{
		return env->NewStringUTF("L5kpra7/pJdZpsBfYiyt5R3u23A7//4EUnj98+FpSsg=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a90(JNIEnv* env)
	{
		return env->NewStringUTF("BzniibhlbEvTNfpgoBbCfoHDN+ZeHzJbnIYtEjAHAiU=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a91(JNIEnv* env)
	{
		return env->NewStringUTF("U5JHSL9lMu8Q4KZgxwd7GlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a92(JNIEnv* env)
	{
		return env->NewStringUTF("jkPgOV2V9U1akLHTae8hqCwndOSlpSUws/NEky1Uq/5wTvZ4ReRmtH2ysXONsAmaQ1OzgARMi/29DE4jThmsc1Ub4Y/aHf6l20uRWZynTPc=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a93(JNIEnv* env)
	{
		return env->NewStringUTF("YSRSDRlSmQJ035ukhfGVdx8IJOwqKOvHzUzQE+uYDWwh9pQn3fHjABWfn5U2ZJdKVFXeGhPbmE9mfQeg2iiwdA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a98(JNIEnv* env)
	{
		return env->NewStringUTF("WnisTDJGAQL3NP8tsPDcZQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a112(JNIEnv* env)
	{
		return env->NewStringUTF("jJnaH1HPn8rkkKv2ACwZS0AaZN8u8A3aantomnGuiHA=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a113(JNIEnv* env)
	{
		return env->NewStringUTF("T3dT7F1BYXOO+ki4RS6LmrLJIGYEQjdCJIPxh1CvpgRKA/jwH/X6skBGDmUGBl3EFDUNGGOA2znm1xE3qEC5bVW7yFZmAw+9CqbPRk+KBqx4juTJ4h1k1FdqSk0+e5ndCdMmQHRT2D+FB58/f16PAAyZ4NC2VZuyiYuK01aBUpk=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a114(JNIEnv* env)
	{
		return env->NewStringUTF("kqfeDX63IocM7uo487hJsFc4NDIZQEcmr3xqTupuB2+m5Z2+tl1z4cAA77v3ymuH");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a115(JNIEnv* env)
	{
		return env->NewStringUTF("32+3Uzvexuh1l3elaYRs9lRV3hoT25hPZn0HoNoosHQ=");
	}
}
