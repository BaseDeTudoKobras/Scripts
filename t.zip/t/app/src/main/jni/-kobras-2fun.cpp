#include <jni.h>
#include <string>
#include <unistd.h>
#include <pthread.h>
#include <dirent.h>

static int shh2 = 0;

static int jkt = 0;

static int wsa = 0;

static jboolean bb = false;

static jboolean check = false;

static jboolean rodando = false;

static jboolean checkado = false;

static jboolean CROSS = false;

static jboolean CROSS2 = false;

static jboolean frt = false;

static jboolean r2 = false;

static pthread_t rotina[2];

static pthread_t rotina2[2];

const static char *CLASS_NAME_NATIVECONTEXT = "kobras/f15/vpn/miguel/Kobras";
const static char *METHOD_T_CONTEXT = "mContext";
const static char *METHOD_GETCONTEXT = "()Landroid/content/Context;";

//exit
const static int aze(JNIEnv *env)
{
	jclass classNativ = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(classNativ, METHOD_T_CONTEXT, METHOD_GETCONTEXT);									 
    jobject appContext = env->CallStaticObjectMethod(classNativ, midGetContext);
	
	jfieldID a_r1 = env->GetFieldID(classNativ,"ජේr1", "Ljava/lang/String;");
    jstring r1 = (jstring) env->GetObjectField(appContext, a_r1);
	jfieldID a_r2 = env->GetFieldID(classNativ,"ජේr2", "Ljava/lang/String;");
    jstring r2 = (jstring) env->GetObjectField(appContext, a_r2);
	
	jclass System_class = env->FindClass(env->GetStringUTFChars(r1, NULL));
    jmethodID ovo = env->GetStaticMethodID(System_class,env->GetStringUTFChars(r2, NULL), "(I)V");
    env->CallStaticVoidMethod(System_class, ovo, 0);
	return 0;
}

//ALERTA DIALOG
const static int gol(JNIEnv *env, jobject context, jstring tar, jstring uig)
{
	jclass classNativ = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(classNativ, METHOD_T_CONTEXT, METHOD_GETCONTEXT);									 
    jobject appContext = env->CallStaticObjectMethod(classNativ, midGetContext);
	
	jfieldID a_g1 = env->GetFieldID(classNativ,"ජේg1", "Ljava/lang/String;");
    jstring g1 = (jstring) env->GetObjectField(appContext, a_g1);
	jfieldID a_g2 = env->GetFieldID(classNativ,"ජේg2", "Ljava/lang/String;");
    jstring g2 = (jstring) env->GetObjectField(appContext, a_g2);
	jfieldID a_g3 = env->GetFieldID(classNativ,"ජේg3", "Ljava/lang/String;");
    jstring g3 = (jstring) env->GetObjectField(appContext, a_g3);
	jfieldID a_g4 = env->GetFieldID(classNativ,"ජේg4", "Ljava/lang/String;");
    jstring g4 = (jstring) env->GetObjectField(appContext, a_g4);
	jfieldID a_g5 = env->GetFieldID(classNativ,"ජේg5", "Ljava/lang/String;");
    jstring g5 = (jstring) env->GetObjectField(appContext, a_g5);
	jfieldID a_g6 = env->GetFieldID(classNativ,"ජේg6", "Ljava/lang/String;");
    jstring g6 = (jstring) env->GetObjectField(appContext, a_g6);
	jfieldID a_g7 = env->GetFieldID(classNativ,"ජේg7", "Ljava/lang/String;");
    jstring g7 = (jstring) env->GetObjectField(appContext, a_g7);
	jfieldID a_g8 = env->GetFieldID(classNativ,"ජේg8", "Ljava/lang/String;");
    jstring g8 = (jstring) env->GetObjectField(appContext, a_g8);
	jfieldID a_g9 = env->GetFieldID(classNativ,"ජේg9", "Ljava/lang/String;");
    jstring g9 = (jstring) env->GetObjectField(appContext, a_g9);
	jfieldID a_g10 = env->GetFieldID(classNativ,"ජේg10", "Ljava/lang/String;");
    jstring g10 = (jstring) env->GetObjectField(appContext, a_g10);
	jfieldID a_g11 = env->GetFieldID(classNativ,"ජේg11", "Ljava/lang/String;");
    jstring g11 = (jstring) env->GetObjectField(appContext, a_g11);
	jfieldID a_g12 = env->GetFieldID(classNativ,"ජේg12", "Ljava/lang/String;");
    jstring g12 = (jstring) env->GetObjectField(appContext, a_g12);
	jfieldID a_g13 = env->GetFieldID(classNativ,"ජේg13", "Ljava/lang/String;");
    jstring g13 = (jstring) env->GetObjectField(appContext, a_g13);
	jfieldID a_g14 = env->GetFieldID(classNativ,"ජේg14", "Ljava/lang/String;");
    jstring g14 = (jstring) env->GetObjectField(appContext, a_g14);
	jfieldID a_g15 = env->GetFieldID(classNativ,"ජේg15", "Ljava/lang/String;");
    jstring g15 = (jstring) env->GetObjectField(appContext, a_g15);
	jfieldID a_g16 = env->GetFieldID(classNativ,"ජේg16", "Ljava/lang/String;");
    jstring g16 = (jstring) env->GetObjectField(appContext, a_g16);
	
    jclass rt = env->FindClass(env->GetStringUTFChars(g1, NULL));
    jmethodID rts = env->GetMethodID(rt, env->GetStringUTFChars(g2, NULL), env->GetStringUTFChars(g3, NULL));
    jobject miut = env->NewObject(rt, rts, context);
    jmethodID kah = env->GetMethodID(rt, env->GetStringUTFChars(g4, NULL), env->GetStringUTFChars(g5, NULL));
    env->CallObjectMethod(miut, kah, tar); //env->NewStringUTF(title));
    jmethodID ssg = env->GetMethodID(rt, env->GetStringUTFChars(g6, NULL), env->GetStringUTFChars(g7, NULL));
    env->CallObjectMethod(miut, ssg, uig); //env->NewStringUTF(msg));
    jmethodID sCa = env->GetMethodID(rt, env->GetStringUTFChars(g8, NULL), env->GetStringUTFChars(g9, NULL));
    env->CallObjectMethod(miut, sCa, false);
    jmethodID stB = env->GetMethodID(rt, env->GetStringUTFChars(g10, NULL), env->GetStringUTFChars(g11, NULL));
    env->CallObjectMethod(miut, stB, g12, static_cast<jobject>(NULL));
    jmethodID cre = env->GetMethodID(rt, env->GetStringUTFChars(g13, NULL), env->GetStringUTFChars(g14, NULL));
    jobject crl = env->CallObjectMethod(miut, cre);
    jclass abat = env->FindClass(env->GetStringUTFChars(g15, NULL));
    jmethodID sqw = env->GetMethodID(abat, env->GetStringUTFChars(g16, NULL), "()V");
    env->CallVoidMethod(crl, sqw);
	return 0;
}

//TOAST
const static int bpt(JNIEnv *env, jobject context, jstring text)
{
	jclass classNativ = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(classNativ, METHOD_T_CONTEXT, METHOD_GETCONTEXT);									 
    jobject appContext = env->CallStaticObjectMethod(classNativ, midGetContext);
	
	jfieldID a_u1 = env->GetFieldID(classNativ,"ජේu1", "Ljava/lang/String;");
    jstring u1 = (jstring) env->GetObjectField(appContext, a_u1);
	jfieldID a_u2 = env->GetFieldID(classNativ,"ජේu2", "Ljava/lang/String;");
    jstring u2 = (jstring) env->GetObjectField(appContext, a_u2);
	jfieldID a_u3 = env->GetFieldID(classNativ,"ජේu3", "Ljava/lang/String;");
    jstring u3 = (jstring) env->GetObjectField(appContext, a_u3);
	jfieldID a_u4 = env->GetFieldID(classNativ,"ජේu4", "Ljava/lang/String;");
    jstring u4 = (jstring) env->GetObjectField(appContext, a_u4);
	jfieldID a_u5 = env->GetFieldID(classNativ,"ජේu5", "Ljava/lang/String;");
    jstring u5 = (jstring) env->GetObjectField(appContext, a_u5);
	jfieldID a_u6 = env->GetFieldID(classNativ,"ජේu6", "Ljava/lang/String;");
    jstring u6 = (jstring) env->GetObjectField(appContext, a_u6);
	jfieldID a_u7 = env->GetFieldID(classNativ,"ජේu7", "Ljava/lang/String;");
    jstring u7 = (jstring) env->GetObjectField(appContext, a_u7);
	
	jclass application_context_class = env->FindClass(env->GetStringUTFChars(u1, NULL));
    jmethodID jgetApplicationContext = env->GetMethodID(application_context_class, env->GetStringUTFChars(u2, NULL), env->GetStringUTFChars(u3, NULL));
    jobject context2 = env->CallObjectMethod(context, jgetApplicationContext);
    jclass t_class = env->FindClass(env->GetStringUTFChars(u4, NULL));
    jmethodID ma = env->GetStaticMethodID(t_class, env->GetStringUTFChars(u5, NULL), env->GetStringUTFChars(u6, NULL));
    jobject tt = env->CallStaticObjectMethod(t_class, ma ,context2, text, 1);
    jmethodID siw = env->GetMethodID(t_class, env->GetStringUTFChars(u7, NULL), "()V");
    env->CallVoidMethod(tt, siw);
	return 0;
}

//SharedPreferences
const static jobject cvc(JNIEnv * env)
{
	jclass classNativ = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(classNativ, METHOD_T_CONTEXT, METHOD_GETCONTEXT);									 
    jobject appContext = env->CallStaticObjectMethod(classNativ, midGetContext);
	
	jfieldID a_h1 = env->GetFieldID(classNativ,"ජේh1", "Ljava/lang/String;");
    jstring h1 = (jstring) env->GetObjectField(appContext, a_h1);
	jfieldID a_h2 = env->GetFieldID(classNativ,"ජේh2", "Ljava/lang/String;");
    jstring h2 = (jstring) env->GetObjectField(appContext, a_h2);
	jfieldID a_h3 = env->GetFieldID(classNativ,"ජේh3", "Ljava/lang/String;");
    jstring h3 = (jstring) env->GetObjectField(appContext, a_h3);
	jfieldID a_h4 = env->GetFieldID(classNativ,"ජේh4", "Ljava/lang/String;");
    jstring h4 = (jstring) env->GetObjectField(appContext, a_h4);
	jfieldID a_h5 = env->GetFieldID(classNativ,"ජේh5", "Ljava/lang/String;");
    jstring h5 = (jstring) env->GetObjectField(appContext, a_h5);
	jfieldID a_h6 = env->GetFieldID(classNativ,"ජේh6", "Ljava/lang/String;");
    jstring h6 = (jstring) env->GetObjectField(appContext, a_h6);
	
    jclass cls_ar = env->FindClass(env->GetStringUTFChars(h1, NULL));
    jclass cls_Context = env->FindClass(env->GetStringUTFChars(h2, NULL));
    jmethodID mid_s= env->GetMethodID(cls_ar, env->GetStringUTFChars(h3, NULL), env->GetStringUTFChars(h4, NULL));
    jfieldID fid_E = env->GetStaticFieldID(cls_Context, env->GetStringUTFChars(h5, NULL), "I");
    jint int_E = env->GetStaticIntField(cls_Context, fid_E);
    return env->CallObjectMethod(appContext, mid_s, h6, int_E);
}

//get Shared
const static int guj(JNIEnv * env)
{
	jclass classNativ = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(classNativ, METHOD_T_CONTEXT, METHOD_GETCONTEXT);									 
    jobject appContext = env->CallStaticObjectMethod(classNativ, midGetContext);
	
	
	jfieldID a_h7 = env->GetFieldID(classNativ,"ජේh7", "Ljava/lang/String;");
    jstring h7 = (jstring) env->GetObjectField(appContext, a_h7);
	jfieldID a_h8 = env->GetFieldID(classNativ,"ජේh8", "Ljava/lang/String;");
    jstring h8 = (jstring) env->GetObjectField(appContext, a_h8);
	jfieldID a_h9 = env->GetFieldID(classNativ,"ජේh9", "Ljava/lang/String;");
    jstring h9 = (jstring) env->GetObjectField(appContext, a_h9);
	jfieldID a_h10 = env->GetFieldID(classNativ,"ජේh10", "Ljava/lang/String;");
    jstring h10 = (jstring) env->GetObjectField(appContext, a_h10);
    jclass cls_fer = env->FindClass(env->GetStringUTFChars(h7, NULL));
    jmethodID mid_g = env->GetMethodID(cls_fer, env->GetStringUTFChars(h8, NULL), env->GetStringUTFChars(h9, NULL));
    jobject obj_ss = cvc(env);
	
    return env->CallIntMethod(obj_ss, mid_g, h10, 0);
}

//put Shared
const static jboolean zhj(JNIEnv * env, int value)
{
	jclass classNativ = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(classNativ, METHOD_T_CONTEXT, METHOD_GETCONTEXT);									 
    jobject appContext = env->CallStaticObjectMethod(classNativ, midGetContext);
	
	
	jfieldID a_h10 = env->GetFieldID(classNativ,"ජේh10", "Ljava/lang/String;");
    jstring h10 = (jstring) env->GetObjectField(appContext, a_h10);
	
	jfieldID a_h11 = env->GetFieldID(classNativ,"ජේh11", "Ljava/lang/String;");
    jstring h11 = (jstring) env->GetObjectField(appContext, a_h11);
	jfieldID a_h12 = env->GetFieldID(classNativ,"ජේh12", "Ljava/lang/String;");
    jstring h12 = (jstring) env->GetObjectField(appContext, a_h12);
	jfieldID a_h13 = env->GetFieldID(classNativ,"ජේh13", "Ljava/lang/String;");
    jstring h13 = (jstring) env->GetObjectField(appContext, a_h13);
	jfieldID a_h14 = env->GetFieldID(classNativ,"ජේh14", "Ljava/lang/String;");
    jstring h14 = (jstring) env->GetObjectField(appContext, a_h14);
	jfieldID a_h15 = env->GetFieldID(classNativ,"ජේh15", "Ljava/lang/String;");
    jstring h15 = (jstring) env->GetObjectField(appContext, a_h15);
	jfieldID a_h16 = env->GetFieldID(classNativ,"ජේh16", "Ljava/lang/String;");
    jstring h16 = (jstring) env->GetObjectField(appContext, a_h16);
	jfieldID a_h17 = env->GetFieldID(classNativ,"ජේh17", "Ljava/lang/String;");
    jstring h17 = (jstring) env->GetObjectField(appContext, a_h17);
	
    jclass cls_fers = env->FindClass(env->GetStringUTFChars(h11, NULL));
    jclass cls_or = env->FindClass(env->GetStringUTFChars(h12, NULL));
    jmethodID mid_t = env->GetMethodID(cls_fers, env->GetStringUTFChars(h13, NULL), env->GetStringUTFChars(h14, NULL));
    jmethodID mid_pg = env->GetMethodID(cls_or, env->GetStringUTFChars(h15, NULL), env->GetStringUTFChars(h16, NULL));
    jmethodID mid_it = env->GetMethodID(cls_or, env->GetStringUTFChars(h17, NULL), "()Z");
    jobject obj_ss = cvc(env);
    jobject obj_or = env->CallObjectMethod(obj_ss, mid_t);
    env->CallObjectMethod(obj_or, mid_pg, h10, value);

    return env->CallBooleanMethod(obj_or, mid_it);
}

JNIEnv *env1;
//ATT TEMPO
const static int att(JNIEnv *env, jobject thiz)
{
	jclass java_class = env->GetObjectClass(thiz);
	jmethodID method_string = env->GetMethodID(java_class, "R_1", "(Ljava/lang/String;)V");
	if (!r2)
	{
		wsa = guj(env);
		r2 = true;
	}
	int w = wsa;
	int a = w / 3600;
	w = w % 3600;
	int b = w / 60;
	int c = w % 60;
	char mh[3], mm[3], ms[3], zil[21];
	sprintf(mh, "%d", a);
	getchar();
	sprintf(mm, "%d", b);
	getchar();
	sprintf(ms, "%d", c);
	getchar();
	if(a < 10)
	{
		sprintf(mh, "0%d", a);
		getchar();
	}
	if(b < 10)
	{
		sprintf(mm, "0%d", b);
		getchar();
	}
	if(c < 10)
	{
		sprintf(ms, "0%d", c);
		getchar();
	}
	sprintf(zil, "%s:%s:%s", mh, mm, ms);
	getchar();
	env->CallVoidMethod(thiz, method_string, env->NewStringUTF(zil));
	return 0;
}

JNIEnv *env3;
void * rotina_f2( void * p_param )
{
	jobject abvcv = (jobject)p_param;
	check = true;
	(void) sleep(1);
	if (rodando)
	{
		aze(env3);
	}
	//pthread_join( rotina, NULL );
	pthread_exit( 0 );
}

static int nyt(JNIEnv *env, jobject thiz)
{
	env3 = env;
	pthread_create( &rotina2[0], NULL, rotina_f2, &thiz );
	return 0;
}

JNIEnv *env2;

void * rotina_f1( void * p_param )
{
	jobject abvcv = (jobject)p_param;
	check = true;
	(void) sleep(1);
	if (shh2 <= wsa || wsa >= 86400)
	{
		aze(env2);
	}
	//pthread_join( rotina, NULL );
	pthread_exit( 0 );
}

static int uyt(JNIEnv *env, jobject thiz)
{
	env2 = env;
	pthread_create( &rotina[0], NULL, rotina_f1, &thiz );
	return 0;
}

//ADD TEMPO
const static int cxg(JNIEnv *env, jobject thiz, jint n)
{
	jclass java_class = env->GetObjectClass(thiz);
	jmethodID method_int = env->GetMethodID(java_class, "R_2", "(I)V");
	switch(n)
	{
		case 1:
		{
			wsa = wsa + 3600;
			break;
		}
		case 2:
		{
			wsa = wsa + 5400;
			break;
		}
		case 3:
		{
			wsa = wsa + 7200;
			break;
		}
		case 4:
		{
			wsa = wsa + 9000;
			break;
		}
		case 5:
		{
			wsa = wsa + 10800;
			break;
		}
	}
	if (wsa > 86400)
	{
		wsa = 86400;
		env->CallVoidMethod(thiz, method_int, 6);
	}
	else
	{
		env->CallVoidMethod(thiz, method_int, n);
	}
	zhj(env, wsa);
	att(env, thiz);
	env->CallVoidMethod(thiz, method_int, 7);
	return 0;
}

static int start24(JNIEnv *env, jobject thiz)
{
	const jclass java_class = env->GetObjectClass(thiz);
	const jmethodID method_msg = env->GetMethodID(java_class, "msg", "(I)V");
	const jmethodID method_int = env->GetMethodID(java_class, "L1", "(I)V");
	if (!frt)
	{
		bb = true;
		frt = true;
		uyt(env, thiz);
	}
	if (wsa <= 86400)
	{
		if (bb)
		{
			if (wsa == 3601 || wsa == 1801 || wsa == 301)
			{
				env->CallVoidMethod(thiz, method_msg, 1);
			}
			wsa--;
			if (wsa <= 0)
			{
				env->CallVoidMethod(thiz, method_int, 10);
				wsa = 0;
				zhj(env, wsa);
				att(env, thiz);
				bb = false;
				nyt(env, thiz);
				env->CallVoidMethod(thiz, method_msg, 2);
			}
			zhj(env, wsa);
		}
	}
	att(env, thiz);
	return 0;
}

static jboolean chula(JNIEnv *env)
{
	jclass activity = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(activity, METHOD_T_CONTEXT, METHOD_GETCONTEXT);									 
    jobject context = env->CallStaticObjectMethod(activity, midGetContext);
	
	jfieldID a_str2r = env->GetFieldID(activity,"ජේ3rs", "Ljava/lang/String;");
    jstring a2r = (jstring) env->GetObjectField(context, a_str2r);
	jfieldID a_str2s = env->GetFieldID(activity,"ජේ3ss", "Ljava/lang/String;");
    jstring a2s = (jstring) env->GetObjectField(context, a_str2s);
	jfieldID a_str2t = env->GetFieldID(activity,"ජේ3ts", "Ljava/lang/String;");
    jstring a2t = (jstring) env->GetObjectField(context, a_str2t);
	
	jclass contextClass = env->GetObjectClass(context);
    jmethodID mk1 = env->GetMethodID(contextClass, env->GetStringUTFChars(a2r, NULL), env->GetStringUTFChars(a2s, NULL));
    jobject mk2 = env->CallObjectMethod(context, mk1);
    jclass mk3 = env->GetObjectClass(mk2);
    jfieldID mk4 = env->GetFieldID(mk3, env->GetStringUTFChars(a2t, NULL), "Ljava/lang/String;");
    jstring mk5 = (jstring)env->GetObjectField(mk2, mk4);
	
	return mk5 == NULL;
}

static jboolean chula2(JNIEnv *env)
{
	jclass activity = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(activity, METHOD_T_CONTEXT, METHOD_GETCONTEXT);									 
    jobject context = env->CallStaticObjectMethod(activity, midGetContext);
	
	jfieldID a_str2r = env->GetFieldID(activity,"ජේ3rs", "Ljava/lang/String;");
    jstring a2r = (jstring) env->GetObjectField(context, a_str2r);
	jfieldID a_str2s = env->GetFieldID(activity,"ජේ3ss", "Ljava/lang/String;");
    jstring a2s = (jstring) env->GetObjectField(context, a_str2s);
	jfieldID a_str2t = env->GetFieldID(activity,"ජේ32ts", "Ljava/lang/String;");
    jstring a2t = (jstring) env->GetObjectField(context, a_str2t);
	
	jclass contextClass = env->GetObjectClass(context);
    jmethodID mk1 = env->GetMethodID(contextClass, env->GetStringUTFChars(a2r, NULL), env->GetStringUTFChars(a2s, NULL));
    jobject mk2 = env->CallObjectMethod(context, mk1);
    jclass mk3 = env->GetObjectClass(mk2);
    jfieldID mk4 = env->GetFieldID(mk3, env->GetStringUTFChars(a2t, NULL), "Ljava/lang/String;");
    jstring mk5 = (jstring)env->GetObjectField(mk2, mk4);
	
	struct dirent *d;
    DIR *dr;
	dr = opendir(env->GetStringUTFChars(mk5, NULL));
	int se = 0;
	
	jfieldID a_tp1 = env->GetFieldID(activity,"ජේtp1", "Ljava/lang/String;");
    jstring tp1 = (jstring) env->GetObjectField(context, a_tp1);
	jfieldID a_tp2 = env->GetFieldID(activity,"ජේtp2", "Ljava/lang/String;");
    jstring tp2 = (jstring) env->GetObjectField(context, a_tp2);
	jfieldID a_tp3 = env->GetFieldID(activity,"ජේtp3", "Ljava/lang/String;");
    jstring tp3 = (jstring) env->GetObjectField(context, a_tp3);
	jfieldID a_tp4 = env->GetFieldID(activity,"ජේtp4", "Ljava/lang/String;");
    jstring tp4 = (jstring) env->GetObjectField(context, a_tp4);
	jfieldID a_tp5 = env->GetFieldID(activity,"ජේtp5", "Ljava/lang/String;");
    jstring tp5 = (jstring) env->GetObjectField(context, a_tp5);
	jfieldID a_tp6 = env->GetFieldID(activity,"ජේtp6", "Ljava/lang/String;");
    jstring tp6 = (jstring) env->GetObjectField(context, a_tp6);
	jfieldID a_tp7 = env->GetFieldID(activity,"ජේtp7", "Ljava/lang/String;");
    jstring tp7 = (jstring) env->GetObjectField(context, a_tp7);
	jfieldID a_tp8 = env->GetFieldID(activity,"ජේtp8", "Ljava/lang/String;");
    jstring tp8 = (jstring) env->GetObjectField(context, a_tp8);
	jfieldID a_tp12 = env->GetFieldID(activity,"ජේtp12", "Ljava/lang/String;");
    jstring tp12 = (jstring) env->GetObjectField(context, a_tp12);
	
	const char *kA1 = env->GetStringUTFChars(tp1, NULL);
    const char *kA2 = env->GetStringUTFChars(tp2, NULL);
	const char *kA3 = env->GetStringUTFChars(tp3, NULL);
	const char *kA4 = env->GetStringUTFChars(tp4, NULL);
	const char *kA5 = env->GetStringUTFChars(tp5, NULL);
	const char *kA6 = env->GetStringUTFChars(tp6, NULL);
	const char *kA7 = env->GetStringUTFChars(tp7, NULL);
	const char *kA8 = env->GetStringUTFChars(tp8, NULL);
	const char *kA12 = env->GetStringUTFChars(tp12, NULL);
	return true;
    while ((d = readdir(dr)) != NULL)
    {
    	if (strcmp(kA1, d->d_name) != 0 && strcmp(kA2, d->d_name) != 0)
		{
			if (strcmp(kA3, d->d_name) == 0 || strcmp(kA4, d->d_name) == 0 || strcmp(kA5, d->d_name) == 0)
			{
				return false;
			}
			if (strcmp(kA6, d->d_name) != 0 && strcmp(kA7, d->d_name) != 0 && strcmp(kA8, d->d_name) != 0 && strcmp(kA12, d->d_name) != 0)
			{
				return false;
			}
        	se++;
		}
    }
    closedir(dr);
	return se == 2;
}

extern "C"
{
	JNIEXPORT jboolean JNICALL Java_kobras_f15_vpn_miguel_Fun_r(JNIEnv *env, jobject thiz)
	{
    	return bb;
	}
	
	JNIEXPORT void JNICALL Java_kobras_f15_vpn_miguel_Game_M1(JNIEnv *env, jobject thiz, jint n)
	{
		jkt = n;
	}
	
	JNIEXPORT void JNICALL Java_kobras_f15_vpn_miguel_Fun_L1(JNIEnv *env, jobject thiz, jint n)
	{
		jclass java_class = env->GetObjectClass(thiz);
		switch(n)
		{
			case 1:
			{
				//37
				if (jkt == 37)
				{
					cxg(env, thiz, n);
					jkt = 0;
				}
				break;
			}
			case 2:
			{
				//37
				if (jkt == 37)
				{
					cxg(env, thiz, n);
					jkt = 0;
				}
				break;
			}
			case 3:
			{
				//37
				if (jkt == 37)
				{
					cxg(env, thiz, n);
					jkt = 0;
				}
				break;
			}
			case 4:
			{
				//37
				if (jkt == 37)
				{
					cxg(env, thiz, n);
					jkt = 0;
				}
				break;
			}
			case 5:
			{
				//37
				if (jkt == 37)
				{
					cxg(env, thiz, n);
					jkt = 0;
				}
				break;
			}
			case 6:
			{
				att(env, thiz);
				break;
			}
			case 7:
			{
				if (!frt)
				{
					rodando = true;
					if (wsa < 300)
					{
						wsa = 300;
					}
					shh2 = wsa;
				}
				att(env, thiz);
				checkado = JNI_TRUE;
				check = false;
				jmethodID method_ = env->GetMethodID(java_class, "A_1", "()V");
				env->CallVoidMethod(thiz, method_);
				break;
			}
			case 8:
			{
				start24(env, thiz);
				break;
			}
			case 9:
			{
				bb = false;
				frt = false;
				break;
			}
			case 10:
			{
				jmethodID method_ = env->GetMethodID(java_class, "A_1", "()V");
				env->CallVoidMethod(thiz, method_);
				break;
			}
		}
	}
	
	JNIEXPORT void JNICALL Java_kobras_f15_vpn_miguel_Game_L3(JNIEnv *env, jobject thiz, jint n)
	{
		jclass mainactivity = env->GetObjectClass(thiz);
		switch(n)
		{
			case 1:
			{
				jfieldID a_str = env->GetFieldID(mainactivity,"ජේ1s", "Ljava/lang/String;");
    			jstring data = (jstring) env->GetObjectField(thiz, a_str);
				bpt(env, thiz, data);
				break;
			}
			case 2:
			{
				jfieldID a_str = env->GetFieldID(mainactivity,"ජේ2s", "Ljava/lang/String;");
    			jstring data = (jstring) env->GetObjectField(thiz, a_str);
				bpt(env, thiz, data);
				break;
			}
			case 3:
			{
				jfieldID a_str = env->GetFieldID(mainactivity,"ජේ3s", "Ljava/lang/String;");
    			jstring data = (jstring) env->GetObjectField(thiz, a_str);
				bpt(env, thiz, data);
				break;
			}
			case 4:
			{
				jfieldID a_str = env->GetFieldID(mainactivity,"ජේ4s", "Ljava/lang/String;");
    			jstring data = (jstring) env->GetObjectField(thiz, a_str);
				bpt(env, thiz, data);
				break;
			}
			case 5:
			{
				jfieldID a_str = env->GetFieldID(mainactivity,"ජේ5s", "Ljava/lang/String;");
    			jstring data = (jstring) env->GetObjectField(thiz, a_str);
				bpt(env, thiz, data);
				break;
			}
			case 6:
			{
				jfieldID a_str = env->GetFieldID(mainactivity,"ජේ6s", "Ljava/lang/String;");
    			jstring data = (jstring) env->GetObjectField(thiz, a_str);
				bpt(env, thiz, data);
				jfieldID a_strz = env->GetFieldID(mainactivity,"ජේ6s2", "Ljava/lang/String;");
    			jstring dataz = (jstring) env->GetObjectField(thiz, a_strz);
				gol(env, thiz, data, dataz);
				break;
			}
			case 7:
			{
				jmethodID method_ = env->GetMethodID(mainactivity, "P_0", "()V");
				env->CallVoidMethod(thiz, method_);
			}
		}
	}
	
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a10(JNIEnv* env)
	{
		if (checkado && bb && CROSS && CROSS2)
		{
			return env->NewStringUTF("JH+BAnTOEIn4nPelTRKl532Q4OdnB5NDm4UO0nZRkFxn71SoSHV4yjOFIt20jxbrWJsxfVsf8Q9+VsStFjx3TgYlJOAnp4u5oBLOKQLHSSuK32tSlcMTzHlL7jXd65I3jLE8VS/J/je3IuNhwCnN9D9i8DGi78yXeK5Zo2CW3Xhbz9N8IkuTQk8b9W1zzsoP+42RQuWqYxgLwCZYAzLL+FZ7VeUNyA4QRMvE9vC2S/aSKdJc+d91hNjzi+5LMWFdhBdLfgjFtw2rWZmShsINUJaksRPWd7DV+TmvUpepPaQp5SuFqWk4tfpOgZZ0icRzaGZQapG5kKe6mB3MZw6V/apJXcYiMdC5u7PDbwt6vf66kvNWqJJ5LKz4mcPqoN7Gr8HKqBjANvttkbL39ZR9LyZ6P9TwHgBDpw5KXZzwI67u7HWMBbo+IhTy+SoTDC/A9JNbp5RU1ROZl98C/rFoPcqbFtC66K7XvT1+GDzHoejor4jcM/5L15VzCf5nuu4AiAadE53R7g3O6kWfb5RVWN59QXa29Kfy3WDeJC6iZ4l9NhvIUFuAx9XIfYhn3OO+tFF2AuGosWVnJqQ1F1UPG8dDkHWg5/VLLNEhSy4nPlNc9pXSe56kd/aKibke59f/fpPZLJD6xMnJB2Lc9cs+M0ZjTFDPCKSFE3VAo76I2H9n+x92UHqEcBmCI8BbN2DSQBPzL4W2cAAkaSNqvoTenW5GkLN0FNOiMEffneXUH2c5lGBfmbkdMTSvRnUgqEcDtBgjefjnMF5+PryPqxc7WtutVwaPPztYgiX0E85HrCNcRQRa3HP5cTe2SnEw7W4MVFXeGhPbmE9mfQeg2iiwdA==");
		}
		else
		{
			return NULL;
		}
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a11(JNIEnv* env)
	{
		if (checkado && bb && CROSS && CROSS2)
		{
			return env->NewStringUTF("qEnSzxjJfWR5LRyUjN+7x47XF6p+ryg3qzJN38ZaODcxgrj33bgGC7owuyr6OxuOsuQM7wFKsFab1e8K0nt7+A==");
		}
		else
		{
			return NULL;
		}
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a12(JNIEnv* env)
	{
		if (checkado && bb && CROSS && CROSS2)
		{
			return env->NewStringUTF("XflTcOTCerHXwXktj3gIABHIU6FLG5NTxfjR4f6YVA4=");
		}
		else
		{
			return NULL;
		}
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a13(JNIEnv* env)
	{
		if (checkado && bb && CROSS && CROSS2)
		{
			return env->NewStringUTF("VD4optSAdEvPVO34Gw9RZYoc8NDQQ4mxIaBlH0tKrmF/fy9bohZDUTfiV9LXelWHoCcNdGRTOrUzPLZ9OcNDxHhsJ/KQTRetw0xkzAKoM/JdP/R3MG5OOU4v2UUpO++s");
		}
		else
		{
			return NULL;
		}
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a14(JNIEnv* env)
	{
		if (checkado && bb && CROSS && CROSS2)
		{
			return env->NewStringUTF("chm1loW5uLfg92dqa118X6hEIr3nAmZpL8QG3x31Jka83D0BDQi8UDwM4dKzUI5V9+a49qhrOR7Ri7LqcOfbfZkNmdekikLK4z9ApMpRXfBN8XufWj0GH2dlA4OX+/jbXlsd0Gb+W3oHSVlr7jZuIVRV3hoT25hPZn0HoNoosHQ=");
		}
		else
		{
			return NULL;
		}
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a15(JNIEnv* env)
	{
		if (checkado && bb && CROSS && CROSS2)
		{
			return env->NewStringUTF("11w7+BRztXcZBd4XlaSvC3hRh3rPwCYGgvULvwbvPnYQqWq/0i2f1/4V7dXzPDoad52kSb4JNlGCjd/loE1uwA==");
		}
		else
		{
			return NULL;
		}
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a15b(JNIEnv* env)
	{
		if (checkado && bb && CROSS && CROSS2)
		{
			return env->NewStringUTF("rrbe0NfHH1Wn/lO57HejN3g/AdPg898yzscsTNCfNfs=");
		}
		else
		{
			return NULL;
		}
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a15c(JNIEnv* env)
	{
		return env->NewStringUTF("p7EYsA20ks9tTiOHH9LaDA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a16(JNIEnv* env)
	{
		if (checkado && bb && CROSS && CROSS2)
		{
			return env->NewStringUTF("4OxV+1Pn1AkJJW2vHMzEhPA0jw+gDmq8nnd8AWSuOPPvLkjtGs4Wx0JMVF/o20qNe8ueDporgGveUeDIQAa3yw==");
		}
		else
		{
			return NULL;
		}
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a17(JNIEnv* env)
	{
		if (checkado && bb && CROSS && CROSS2)
		{
			return env->NewStringUTF("a37sXy+LqSg20tRsdDfrp3hhj4/z+4quxSITZd4fTQ8=");
		}
		else
		{
			return NULL;
		}
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a18(JNIEnv* env)
	{
		if (checkado && bb && CROSS && CROSS2)
		{
			return env->NewStringUTF("uFILnBZsuLh2qbXbHL1dp4fcWBaaFosHlmQyOIi3iucf8/XQ0KFNWlSeWfhvP4jc/+WUaq/vsAkdm4jy+GZCgN4Jsr/eJnPGhc1yaNWeP8FKTQiHMit+krYdj0+hlWOKU+Oq8OecRFk6olaCUXLCYgG/nbYqiXgtuCg0U+ylnWQPl67haji50V8N7L+Cv/l7dHk+txYMx8fIX3FOrZkz3xTaqkWBs+g629sqfg28cYKKl8coKLR4imTtxZFEQ5kHxyG/2eB9qlq1S/cvdYvPjbsCG0JJPniChGMg2Ut/D/yGPU7yThvsNze/L9aKusJB06uFeT/4YKSPhXmTcApHDRtFGTas5KCHK1EB7UojcMbxMAbZ3mhKluXCqKcCypQ+TDf5G1k3MPq2AdgtiS0eJ91FHMWqeUjMjsmHzMTcYIUrqQg9rqqAB2dyFA5lYRXnR/OUwYtN87neJjSGyhPy/PgHCvwIuSqbfisxhY5zs0OF2UKH/0kuGCu0uEZr5NKgrw+Pq44bxx914oBo958p7VRV3hoT25hPZn0HoNoosHQ=");
		}
		else
		{
			return NULL;
		}
	}
	
	
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_d1(JNIEnv* env)
	{
		return env->NewStringUTF("aSh/TS6/1CV+TNF03jWF3FRV3hoT25hPZn0HoNoosHQ=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a89(JNIEnv* env)
	{
		return env->NewStringUTF("e8rKBjEYCFjSfLWeHgGyjKrZiy7jy+yxRCVDWokAc58=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a89j(JNIEnv* env)
	{
		return env->NewStringUTF("OFBybBMpEIFl3/DqEZ2896z7OubfoZBkElqVpYBjJhY=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a71j(JNIEnv* env)
	{
		return env->NewStringUTF("FdpvKt2C9vixYSJlSMWhOBATeXtW4LyDRhoc/3wjJ1c=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a1s(JNIEnv* env)
	{
		return env->NewStringUTF("L4HTwLeAVxaoXump3o/cfTIKRJ7omhSORMiLkLjffnSLX2+/kBt4XSVQYNxe1RP/VFXeGhPbmE9mfQeg2iiwdA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a2s(JNIEnv* env)
	{
		return env->NewStringUTF("MrwOgyBBeuVals3HWrHLbnP5CHFBWk+fgcRJIRW+QAIFj9ogBDVvaxzEdr4PrPRqPbHKE/ZPpMK1hvlGtg2rFA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a3s(JNIEnv* env)
	{
		return env->NewStringUTF("UT/IClCEftOigQLJnQfxNZccz6QbV8eo/yVCEae6uviZCOuggUiU3CSNw+2B/UWR7aCDhvXm8feABglNSVWhXQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a4s(JNIEnv* env)
	{
		return env->NewStringUTF("7kjZ2JTd3vg1pmKmUOldXgFwhoSebEUtEpSjbONXbQgodW8l99x7iixzAyEZv1Yly/zKckiWghIPoHk7KOQoCA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a5s(JNIEnv* env)
	{
		return env->NewStringUTF("GRbWGClpmm5VS/lFjwxyILeOJo9W4hreY5TEWSJu58qucvJ9v3eMOF2IrIVhpKdi2aMHTU0fS2bi1U0W+Jgg+w==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a6s(JNIEnv* env)
	{
		return env->NewStringUTF("DWVfX13MwosO6JfNC3VfS7nR7KOb7m4fIsCwOzWbt3EsFvCy8IPC0izLrbwvrKxA");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a6s2(JNIEnv* env)
	{
		return env->NewStringUTF("YenQQSMwB2VQUCBwDgyjZKZMjMgSRc+W5cV51T7SElDUX0gOPZ5j0VBQR9iFlOA1iIGuVxa3vAIktBz7ihizQVImWXiok1W1StAjtXTo2wDYUCUAbAV0Q92bCtv4ZbmDspBiamzIdH+fHqZI7/3PMWGKiOfliSj0C5AwfGuUf47OiiW5FTYum0SNaYWozJq9vn2+q3ddwp58+5lPQ1/S8A==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a7s(JNIEnv* env)
	{
		return env->NewStringUTF("AotuKkmZTs0H1c8kB5mYk8iKO5rDsNOO9jL9sq5GGnvYrNI4mbaOO7c+La6n50SHVndGz0x9bng+H0zWTHAxszxAfPSVjEXe1bKdjEMNprVzBbI00YT+5vEhL6tHUrNS");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a7s2(JNIEnv* env)
	{
		return env->NewStringUTF("nHIPsKd2cR7MIMncq3yETvEM4Q21xkTMMU5lFWyFOkOI2DZ5q9I7qNq3nUzXdtiL7LdBzFzCez50kA2a1jftfvuier1/Lz/Qu93ZAUnOyf6SZIXuYRafSL2GNZ4DX0LMUpDTS82FeFKrEeilKSn8D2oaMi2Ep/E8XDGM7XI9BGgVz7N7riyB1b6uKAUmSmvK");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a8s(JNIEnv* env)
	{
		return env->NewStringUTF("9DvRnwfzAyb+PjtiQz68LYLnwn5gM/Kbo8xxfyj8a8QjluGTUpy/TWf4/xc4ykuBtG2LM/JPY9HMqlrUwS7ubaUQNePCDCjIO6TjomNjKPs=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_f15_vpn_miguel_a_a8s2(JNIEnv* env)
	{
		return env->NewStringUTF("gP3grLHA9DjG3IfMXyHktnS/oAaH29XzM4WlDYa0hCAoQFk3eila8DVW6wG6VWN7z2DVra5O7PHpzI0PvKmIbn3PPjbEGJR8QmtQuWHo9rnHiRtT999le78iFMtCsCrj5V2O/f+U0f8Uh1hu6KCVNivgNNuLyih0cySMFbJkW6tP3TpJ3Gt4EMUOa0IdOeTflUJtArUrSZzO/z0+LmH8AzcO3XGXJQLOkZ1uzEMkAjNUVd4aE9uYT2Z9B6DaKLB0");
	}
	
	JNIEXPORT void JNICALL Java_kobras_f15_vpn_miguel_Fun_L2(JNIEnv *env, jobject thiz)
	{
		rodando = false;
	}
	
}
	
const static int Unp(const char *source, char *dest, int sourceLen)
{
    short i;
    char highByte, lowByte;

    for (i = 0; i < sourceLen; i++)
	{
        highByte = source[i] >> 4;
        lowByte = source[i] & 0x0f;
        highByte += 0x30;

        if (highByte > 0x39)
		{
            dest[i * 2] = highByte + 0x07;
        } else
		{
            dest[i * 2] = highByte;
        }

        lowByte += 0x30;
        if (lowByte > 0x39)
		{
            dest[i * 2 + 1] = lowByte + 0x07;
        } else
		{
            dest[i * 2 + 1] = lowByte;
        }
    }
	
	return 0;
}

const static jstring ToM(JNIEnv *env, jobject context, jbyteArray source)
{
	jclass activity = env->FindClass(CLASS_NAME_NATIVECONTEXT);
	jfieldID a_str = env->GetFieldID(activity,"ජේ10s", "Ljava/lang/String;");
    jstring a1 = (jstring) env->GetObjectField(context, a_str);
	jfieldID a_str2 = env->GetFieldID(activity,"ජේ11s", "Ljava/lang/String;");
    jstring a2 = (jstring) env->GetObjectField(context, a_str2);
	jfieldID a_str3 = env->GetFieldID(activity,"ජේ12s", "Ljava/lang/String;");
    jstring a3 = (jstring) env->GetObjectField(context, a_str3);
	jfieldID a_str4 = env->GetFieldID(activity,"ජේ13s", "Ljava/lang/String;");
    jstring a4 = (jstring) env->GetObjectField(context, a_str4);
	jfieldID a_str5 = env->GetFieldID(activity,"ජේ14s", "Ljava/lang/String;");
    jstring a5 = (jstring) env->GetObjectField(context, a_str5);
	jfieldID a_str6 = env->GetFieldID(activity,"ජේ15s", "Ljava/lang/String;");
    jstring a6 = (jstring) env->GetObjectField(context, a_str6);
	jfieldID a_str7 = env->GetFieldID(activity,"ජේ16s", "Ljava/lang/String;");
    jstring a7 = (jstring) env->GetObjectField(context, a_str7);
	jfieldID a_str8 = env->GetFieldID(activity,"ජේ17s", "Ljava/lang/String;");
    jstring a8 = (jstring) env->GetObjectField(context, a_str8);
	
    jclass classMessageDigest = env->FindClass(env->GetStringUTFChars(a1, NULL));
    jmethodID midGetInstance = env->GetStaticMethodID(classMessageDigest, env->GetStringUTFChars(a2, NULL), env->GetStringUTFChars(a3, NULL));

    jobject objMessageDigest = env->CallStaticObjectMethod(classMessageDigest, midGetInstance, env->NewStringUTF(env->GetStringUTFChars(a4, NULL)));

    jmethodID midUpdate = env->GetMethodID(classMessageDigest, env->GetStringUTFChars(a5, NULL), env->GetStringUTFChars(a6, NULL));
    env->CallVoidMethod(objMessageDigest, midUpdate, source);
    jmethodID midDigest = env->GetMethodID(classMessageDigest, env->GetStringUTFChars(a7, NULL), env->GetStringUTFChars(a8, NULL));
    jbyteArray objArraySign = (jbyteArray) env->CallObjectMethod(objMessageDigest, midDigest);
    jsize intArrayLength = env->GetArrayLength(objArraySign);
    jbyte *byte_array_elements = env->GetByteArrayElements(objArraySign, NULL);
    size_t length = (size_t) intArrayLength * 2 + 1;
    char *char_result = (char *) malloc(length);
    memset(char_result, 0, length);
    Unp((const char *) byte_array_elements, char_result, intArrayLength);
    *(char_result + intArrayLength * 2) = '\0';

    jstring stringResult = env->NewStringUTF(char_result);
    env->ReleaseByteArrayElements(objArraySign, byte_array_elements, JNI_ABORT);
    free(char_result);

    return stringResult;
}

const static jstring jpd(JNIEnv *env, jobject context) {
    jclass cls = env->GetObjectClass(context);
	jclass activity = env->FindClass(CLASS_NAME_NATIVECONTEXT);
	jfieldID a_str = env->GetFieldID(activity,"ජේ2s", "Ljava/lang/String;");
    jstring a1 = (jstring) env->GetObjectField(context, a_str);
	jfieldID a_str2 = env->GetFieldID(activity,"ජේ3s", "Ljava/lang/String;");
    jstring a2 = (jstring) env->GetObjectField(context, a_str2);
	jfieldID a_str3 = env->GetFieldID(activity,"ජේ4s", "Ljava/lang/String;");
    jstring a3 = (jstring) env->GetObjectField(context, a_str3);
	jfieldID a_str4 = env->GetFieldID(activity,"ජේ5s", "Ljava/lang/String;");
    jstring a4 = (jstring) env->GetObjectField(context, a_str4);
	jfieldID a_str5 = env->GetFieldID(activity,"ජේ6s", "Ljava/lang/String;");
    jstring a5 = (jstring) env->GetObjectField(context, a_str5);
	jfieldID a_str6 = env->GetFieldID(activity,"ජේ7s", "Ljava/lang/String;");
    jstring a6 = (jstring) env->GetObjectField(context, a_str6);
	jfieldID a_str7 = env->GetFieldID(activity,"ජේ8s", "Ljava/lang/String;");
    jstring a7 = (jstring) env->GetObjectField(context, a_str7);
	jfieldID a_str8 = env->GetFieldID(activity,"ජේ9s", "Ljava/lang/String;");
    jstring a8 = (jstring) env->GetObjectField(context, a_str8);
	
	jfieldID a_str9 = env->GetFieldID(activity,"ජේ17s", "Ljava/lang/String;");
    jstring a9 = (jstring) env->GetObjectField(context, a_str9);
	
	jfieldID a_str10 = env->GetFieldID(activity,"ජේai2", "Ljava/lang/String;");
    jstring a10 = (jstring) env->GetObjectField(context, a_str10);
	
    jmethodID mid = env->GetMethodID(cls, env->GetStringUTFChars(a1, NULL), env->GetStringUTFChars(a2, NULL));

    jobject pm = env->CallObjectMethod(context, mid);
    mid = env->GetMethodID(cls, env->GetStringUTFChars(a3, NULL), env->GetStringUTFChars(a10, NULL));
    jstring dA5 = (jstring) env->CallObjectMethod(context, mid);
    cls = env->GetObjectClass(pm);
    mid = env->GetMethodID(cls, env->GetStringUTFChars(a4, NULL), env->GetStringUTFChars(a5, NULL));
						   
    jobject dA4 = env->CallObjectMethod(pm, mid, dA5, 0x40); //GET_SIGNATURES = 64;
    cls = env->GetObjectClass(dA4);
    jfieldID fid = env->GetFieldID(cls, env->GetStringUTFChars(a6, NULL), env->GetStringUTFChars(a7, NULL));
    jobjectArray dA3 = (jobjectArray) env->GetObjectField(dA4, fid);
    jobject dA2 = env->GetObjectArrayElement(dA3, 0);
    cls = env->GetObjectClass(dA2);
    mid = env->GetMethodID(cls, env->GetStringUTFChars(a8, NULL), env->GetStringUTFChars(a9, NULL));
    jbyteArray dA1 = (jbyteArray) env->CallObjectMethod(dA2, mid);

    return ToM(env, context, dA1);
}

const static jboolean jpa(JNIEnv *env, jobject context) {

    jstring kB1 = jpd(env, context);
	
	jclass activity2 = env->FindClass(CLASS_NAME_NATIVECONTEXT);
	jfieldID a_str = env->GetFieldID(activity2,"ජේ1s", "Ljava/lang/String;");
    jstring kB2 = (jstring) env->GetObjectField(context, a_str);
	
    const char *kA1 = env->GetStringUTFChars(kB1, NULL);
    const char *kA2 = env->GetStringUTFChars(kB2, NULL);
    
    jboolean result = JNI_FALSE;
	
    if (kA1 != NULL && kA2 != NULL)
	{
        if (strcmp(kA1, kA2) == 0)
		{
            result = JNI_TRUE;
        }
    }
	CROSS = result;
   
    return result;
}
 
 
const static jboolean jpb(JNIEnv *env)
{
    jclass classNativ = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(classNativ, METHOD_T_CONTEXT, METHOD_GETCONTEXT);
    jobject appContext2 = env->CallStaticObjectMethod(classNativ, midGetContext);
	
    if (appContext2 != NULL)
	{
        jboolean jpc = jpa(env, appContext2);
    	return jpc;
    }
    return JNI_FALSE;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    if (vm->GetEnv((void **) (&env), JNI_VERSION_1_6) != JNI_OK)
	{
        return -1;
    }
    if (!jpb(env))
	{
        return -1;
    }
	if (chula(env))
	{
		CROSS = JNI_TRUE;
		CROSS2 = JNI_TRUE;
	}
	else
	{
		return -1;
	}
	if (!chula2(env))
	{
		return -1;
	}
	
    return JNI_VERSION_1_6;
}
