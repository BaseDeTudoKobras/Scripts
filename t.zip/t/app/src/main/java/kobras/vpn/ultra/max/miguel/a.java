package kobras.vpn.ultra.max.miguel;

import android.content.Context;
import android.content.pm.PackageManager;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import kobras.vpn.ultra.max.miguel.util.Farinha;
import kobras.vpn.ultra.max.miguel.util.Klm;
import kobras.vpn.ultra.max.miguel.MainActivity;

public class a {

	static {System.loadLibrary(ජේ114());}

	static native String a0i();
	public static String ජේ0i() {
		//"{'SERV':[{'N':'CLICK EM CHECAR ATUALIZAÇÃO !'}],'OP':[{'N':'CLICK EM CHECAR ATUALIZAÇÃO !'}]}"
		//"primeira configuração"
		String जी = a0i();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a1();
	public static String ජේ1() {
		//"primeirOpw"
		String जी = a1();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a2();
	public static String ජේ2() {
		//"novau#&"
		String जी = a2();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a3();
	public static String ජේ3() {
		//"ar&Ff32Dsa"
		//senha da atualizacao
		String जी = a3();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a4();
	public static String ජේ4() {
		//"https://raw.githubusercontent.com/BaseDeTudoKobras/KOBRI/Att/4-f-15.txt"
		String जी = a4();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a5();
	public static String ජේ5() {
		//"<b><font color='red'>VERSÃO NÃO OFICIAL</font></b>"
		String जी = a5();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a6();
	public static String ජේ6() {
		//"<b><br>VERSÃO NÃO OFICIAL DA PLAYSTORE !<p>POR FAVOR BAIXE A VERSÃO DA PLAYSTORE !<p></b>"
		String जी = a6();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a7();
	public static String ජේ7() {
		//"<b>BAIXAR AGORA</b>"
		String जी = a7();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a8();
	public static String ජේ8() {
		//"https://play.google.com/store/apps/details?id=kobras.f15.vpn.miguel"
		String जी = a8();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a9();
	public static String ජේ9() {
		//"<b><font color='red'>FECHAR O APP</font></b>"
		String जी = a9();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a10();
	public static String ජේ10() {
		//"{"dns":{"hosts":{"domain:googleapis.cn":"googleapis.com"},"servers":["8.8.8.8"]},"inbounds":[{"listen":"127.0.0.1","port":10808,"protocol":"socks","settings":{"auth":"noauth","udp":true,"userLevel":8},"sniffing":{"destOverride":["http","tls"],"enabled":true},"tag":"socks"},{"listen":"127.0.0.1","port":10809,"protocol":"http","settings":{"userLevel":8},"tag":"http"}],"log":{"loglevel":"warning"},"outbounds":[{"mux":{"concurrency":8,"enabled":false},"protocol":""
		String जी = a10();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a11();
	public static String ජේ11() {
		//"","settings":{"vnext":[{"address":""
		String जी = a11();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a12();
	public static String ජේ12() {
		//"","port":"
		String जी = a12();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a13();
	public static String ජේ13() {
		//","users":[{"alterId":0,"encryption":"none","flow":"","id":""
		String जी = a13();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a14();
	public static String ජේ14() {
		//"","level":8,"security":"auto"}]}]},"streamSettings":{"network":"ws","security":""
		String जी = a14();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a15();
	public static String ජේ15() {
		//"","tlsSettings":{"allowInsecure":false,"serverName":""
		String जी = a15();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a16();
	public static String ජේ16() {
		//""},"wsSettings":{"headers":{"Host":""
		String जी = a16();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a17();
	public static String ජේ17() {
		//""},"path":""
		String जी = a17();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a18();
	public static String ජේ18() {
		//""}},"tag":"proxy"},{"protocol":"freedom","settings":{},"tag":"direct"},{"protocol":"blackhole","settings":{"response":{"type":"http"}},"tag":"block"}],"routing":{"domainMatcher":"mph","domainStrategy":"IPIfNonMatch","rules":[{"ip":["8.8.8.8"],"outboundTag":"proxy","port":"53","type":"field"}]}}"
		String जी = a18();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a19();
	public static String ජේ19() {
		//"possicaoOP"
		String जी = a19();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a20();
	public static String ජේ20() {
		//"ca-app-pub-9481915026091262/7983386511"
		String जी = a20();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a21();
	public static String ජේ21() {
		//"TEMPO ADICIONADO"
		String जी = a21();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a22();
	public static String ජේ22() {
		//"ca-app-pub-9481915026091262/4603039547"
		String जी = a22();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a23();
	public static String ජේ23() {
		//"Manual"
		String जी = a23();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a24();
	public static String ජේ24() {
		//"UP"
		//seria a OPERADORA
		String जी = a24();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a25();
	public static String ජේ25() {
		//"<b><font color='red'>COLOQUE UM HOST MANUAL PARA CONECTAR !</font></b>"
		String जी = a25();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a26();
	public static String ජේ26() {
		//"CE"
		//seria o SERVIDOR
		String जी = a26();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a2z6();
	public static String ජේ2z6() {
		//"SSL"
		// seria o TLS
		String जी = a2z6();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a2v6();
	public static String ජේ2v6() {
		//"TI"
		//seria o TIPO
		String जी = a2v6();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a27();
	public static String ජේ27() {
		//"UI"
		//seria o UUID
		String जी = a27();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a28();
	public static String ජේ28() {
		//"PO"
		//seria a PORTA
		String जी = a28();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a29();
	public static String ජේ29() {
		//"PA"
		//seria o PATH
		String जी = a29();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a30();
	public static String ජේ30() {
		//"CLIQUE EM CHECAR ATUALIZAÇÃO !"
		String जी = a30();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a31();
	public static String ජේ31() {
		//"SERV"
		//seria SERVIDORES
		String जी = a31();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a32();
	public static String ජේ32() {
		//"OP"
		//seria OPERADORAS
		String जी = a32();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a33();
	public static String ජේ33() {
		//"possicaoSE"
		String जी = a33();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a34();
	public static String ජේ34() {
		//"N"
		//seria Nome
		String जी = a34();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a35();
	public static String ජේ35() {
		//"NomeServer"
		String जी = a35();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a36();
	public static String ජේ36() {
		//"tc"
		String जी = a36();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a37();
	public static String ජේ37() {
		//"Host WebSocket"
		String जी = a37();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a38();
	public static String ජේ38() {
		//"SALVAR"
		String जी = a38();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a39();
	public static String ජේ39() {
		//"CANCELAR"
		String जी = a39();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a40();
	public static String ජේ40() {
		//"<b>"
		String जी = a40();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a41();
	public static String ජේ41() {
		//"</b>"
		String जी = a41();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a42();
	public static String ජේ42() {
		//"OK"
		String जी = a42();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a43();
	public static String ජේ43() {
		//"<b><font color='black'>"
		String जी = a43();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a44();
	public static String ජේ44() {
		//" </font></b>"
		String जी = a44();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a45();
	public static String ජේ45() {
		//"<b><font color='red'>"
		String जी = a45();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a46();
	public static String ජේ46() {
		//"%d:%02d:%02d"
		String जी = a46();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a47();
	public static String ජේ47() {
		//"Tempo restante: "
		String जी = a47();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a48();
	public static String ජේ48() {
		//"tempo"
		String जी = a49();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a49();
	public static String ජේ49() {
		//"ca-app-pub-9481915026091262/2985693789"
		String जी = a49();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a50();
	public static String ජේ50() {
		//"1.18"
		//checar versao
		String जी = a50();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a51();
	public static String ජේ51() {
		//"Ver1"
		String जी = a51();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a52();
	public static String ජේ52() {
		//"LISTA DE SERVIDORES ATUALIZADA"
		String जी = a52();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a53();
	public static String ජේ53() {
		//"LISTA DAS OPERADORAS ATUALIZADA"
		String जी = a53();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a54();
	public static String ජේ54() {
		//"LISTAS ATUALIZADAS"
		String जी = a54();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a55();
	public static String ජේ55() {
		//"NOVA ATUALIZAÇÃO"
		String जी = a55();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a56();
	public static String ජේ56() {
		//"Nova versão disponivel na Playstore !!"
		String जी = a56();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a57();
	public static String ජේ57() {
		//"DEPOIS"
		String जी = a57();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a58();
	public static String ජේ58() {
		//"ATUALIZAÇÃO DE LISTA OBRIGATÓRIA !"
		String जी = a58();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a59();
	public static String ජේ59() {
		//"Necessita de acesso a internet para atualizar !"
		String जी = a59();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a60();
	public static String ජේ60() {
		//"ATUALIZAR"
		String जी = a60();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a61();
	public static String ජේ61() {
		//"CONECTADO"
		String जी = a61();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a62();
	public static String ජේ62() {
		//"VPN"
		String जी = a62();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a63();
	public static String ජේ63() {
		//"key"
		String जी = a63();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a64();
	public static String ජේ64() {
		//"Servidor:"
		String जी = a64();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a65();
	public static String ජේ65() {
		//"setUsesChronometer"
		String जी = a65();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a66();
	public static String ජේ66() {
		//"KOBRAS"
		String जी = a66();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a67();
	public static String ජේ67() {
		//"F-15"
		String जी = a67();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a68();
	public static String ජේ68() {
		//"Dw: "
		String जी = a68();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a69();
	public static String ජේ69() {
		//"↓  Up: "
		String जी = a69();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a70();
	public static String ජේ70() {
		//"↑"
		String जी = a70();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a71();
	public static String ජේ71() {
		//"GET"
		String जी = a71();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a72();
	public static String ජේ72() {
		//"error"
		String जी = a72();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a73();
	public static String ජේ73() {
		//"ca-app-pub-9481915026091262/1363031405"
		//Inter Premio
		String जी = a73();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a74();
	public static String ජේ74() {
		//"interPinter"
		String जी = a74();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a75();
	public static String ජේ75() {
		//"-T-"
		String जी = a75();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a76();
	public static String ජේ76() {
		//"-H-"
		String जी = a76();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a77();
	public static String ජේ77() {
		//"-T-H-"
		String जी = a77();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a78();
	public static String ජේ78() {
		//"TLS P-443"
		String जी = a78();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a79();
	public static String ජේ79() {
		//"HTTP P-80"
		String जी = a79();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a80();
	public static String ජේ80() {
		//"tlsTu"
		String जी = a80();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a81();
	public static String ජේ81() {
		//"-M-"
		String जी = a81();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a82();
	public static String ජේ82() {
		//"tls"
		String जी = a82();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a83();
	public static String ජේ83() {
		//"VMESS"
		String जी = a83();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a84();
	public static String ජේ84() {
		//"VLESS"
		String जी = a84();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a85();
	public static String ජේ85() {
		//"443"
		String जी = a85();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a86();
	public static String ජේ86() {
		//"80"
		String जी = a86();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a87();
	public static String ජේ87() {
		//":  "
		String जी = a87();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a88();
	public static String ජේ88() {
		//"com.google.android.gms.ads.APPLICATION_ID"
		String जी = a88();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a89();
	public static String ජේ89() {
		//"ca-app-pub-9481915026091262~3085766487"
		String जी = a89();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a90();
	public static String ජේ90() {
		//" com.google.android.gms.ads.AdActivity}"
		String जी = a90();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a91();
	public static String ජේ91() {
		//" com.google.android.gms.common.api.GoogleApiActivity}"
		String जी = a91();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a92();
	public static String ජේ92() {
		//" com.google.android.gms.ads.MobileAdsInitProvider}"
		String जी = a92();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a93();
	public static String ජේ93() {
		//" com.google.android.gms.ads.AdService}"
		String जी = a93();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a94();
	public static String ජේ94() {
		//"1800000"
		String जी = a94();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a95();
	public static String ජේ95() {
		//"1801000"
		String जी = a95();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a96();
	public static String ජේ96() {
		//"180000"
		String जी = a96();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a97();
	public static String ජේ97() {
		//"181000"
		String जी = a97();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a98();
	public static String ජේ98() {
		//"1000"
		String जी = a98();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a99();
	public static String ජේ99() {
		//"60000"
		String जी = a99();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a100();
	public static String ජේ100() {
		//"18000000"
		String जी = a100();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a101();
	public static String ජේ101() {
		//"VERIFICANDO ATUALIZAÇÃO..."
		String जी = a101();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a102();
	public static String ජේ102() {
		//"CARREGANDO ANÚNCIO...<br></br><br></br>Espere o anúncio ser carregado !<br></br><br></br>Após assistir o anúncio seu tempo será renovado para 5 horas de conexão"
		String जी = a102();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a103();
	public static String ජේ103() {
		//"ADICIONAR TEMPO..."
		String जी = a103();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a104();
	public static String ජේ104() {
		//"ADD TEMPO\ncontém ANÚNCIO"
		String जी = a104();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a105();
	public static String ජේ105() {
		//"AGUARDE"
		String जी = a105();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a106();
	public static String ජේ106() {
		//"CARREGANDO..."
		String जी = a106();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a107();
	public static String ජේ107() {
		//"VERIFICAR ATUALIZAÇÃO\ncontém ANÚNCIO"
		String जी = a107();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a108();
	public static String ජේ108() {
		//"ACABANDO O TEMPO"
		String जी = a108();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a109();
	public static String ජේ109() {
		//"Menos de 30 minutos, renove o acesso"
		String जी = a109();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a110();
	public static String ජේ110() {
		//"SEU TEMPO ACABOU !"
		String जी = a110();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a111();
	public static String ජේ111() {
		//"Conecte-se de novo e renove o acesso"
		String जी = a111();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a112();
	public static String ජේ112() {
		//"Iniciando VPN..."
		String जी = a112();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a113();
	public static String ජේ113() {
		//"https://raw.githubusercontent.com/BaseDeTudoKobras/KOBRI/BaseDeTudoKobras-filmis/ok.txt"
		String जी = a113();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	
	
	
	//carrega lib
	public static String ජේ114() {
		//"-kobras-2"
		String जी = new String(new byte[] {72,77,79,49,104,82,87,101,102,75,104,65,67,90,83,76,117,78,52,84,120,76,50,117,113,50,52,72,102,71,121,70,87,51,75,120,119,100,111,77,115,76,54,110,55,52,69,119,104,97,110,90,78,71,77,81,50,89,56,87,43,120,80,99});
		try {
			return ජजlी13(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}


	static native String a3e();
	public static String ජේ3e() {
		//"GoiabadAs"
		String जी = a3e();

		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}

	public static String ජේтыजीش() {
		Context ش = MainActivity.mContext;
		StringBuilder sb = new StringBuilder();
		PackageManager pm = ش.getPackageManager();
		String जी = pm.getInstallerPackageName(ش.getPackageName());
		String ты = "";
		try {
			ты = ش.getPackageManager().getPackageInfo(ش.getPackageName(), 0).versionName;
		} catch (PackageManager.NameNotFoundException ignored) {
		}
		if (जी == null || !जी.contentEquals(ජේ0())) {
			//ты = ජේ00().replace(ජේ000(), ты);
			ты = ජේ3e().replace(ජේ000(), ты);
			//ජේ0000()
		} else {
			ты = ජේ3e().replace(ජේ000(), ты);
			//ජේ00()
		}
		sb.append(ты);
		return sb.toString();
	}
	static native String a0();
	public static String ජේ0() {
		//"com.android.vending"
		String जी = a0();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a00();
	public static String ජේ00() {
		//"GoiabadAs"
		String जी = a00();

		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a000();
	public static String ජේ000() {
		//"{{appVersion}}"
		String जी = a000();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}
	static native String a0000();
	public static String ජේ0000() {
		//"Brasileiros"
		String जी = a0000();
		try {
			return ජजlी12(ජजी(जी));
		} catch (Exception e) {
			return null;
		}
	}

	public static String ජේ01() {
		//"AES"
		String जी = new String(new byte[] {65,69,83});
		return जी;
	}

	public static String ජේ02() {
		//"1234567891234567"
		String जी = new String(new byte[] {49,50,51,52,53,54,55,56,57,49,50,51,52,53,54,55});
		return जी;
	}

	public static Key ජ() throws Exception {
		Key ජ0 = new SecretKeySpec(ජේ02().getBytes(), ජේ01());
		return ජ0;
	}

	public static String ජजी(String ජजी4) throws Exception {
		Key ජजी2 = ජ();
		Cipher ජज1ी = Cipher.getInstance(ජේ01());
		ජज1ी.init(Cipher.DECRYPT_MODE, ජजी2);
		byte[] ජजी3 = new Farinha().decodeBase64(ජजी4.getBytes());
		byte[] ජजी00 = ජज1ी.doFinal(ජजी3);
		return new String(ජजी00);
	}
	
	static native String ab0();
	public static String ජaේ0() {
		//"gyGtPp4Gz"
		//senha da senha da senha
		String जी = ab0();
		try {
			return Klm.rtir(ජजी(जी), ජजlी00());
		} catch (Exception e) {
			return null;
		}
	}
	static native String ab01();
	public static String ජaේ01() {
		//"Klrt53FrBv"
		//senha da senha
		String जी = ab01();
		try {
			return Klm.rtir(ජजी(जी), ජaේ0());
		} catch (Exception e) {
			return null;
		}
	}
	static native String ab03();
	public static String ජaේ03() {
		//"hu562AbU0"
		//senha das escritas
		String जी = ab03();
		try {
			return Klm.rtir(ජजी(जी), ජaේ01());
		} catch (Exception e) {
			return null;
		}
	}
	
	
	
	public static String ජaේz0() {
		//"gyyt54Gz"
		//senha da senha da senha da lib
		String जी = new String(new byte[] {120,65,67,112,121,78,83,52,75,52,65,109,77,73,109,82,99,53,74,57,52,65,61,61});
		try {
			return ජजी(जी);
		} catch (Exception e) {
			return null;
		}
	}
	
	public static String ජaේz01() {
		//"girt53FrBv"
		//senha da senha da lib
		String जी = new String(new byte[] {65,110,51,106,66,53,47,121,79,54,75,75,114,101,114,67,111,50,103,116,116,105,57,70,68,106,119,99,101,78,101,52,110,79,97,117,99,43,75,106,113,74,86,109,109,43,117,119,47,122,104,89,52,78,99,98,77,43,54,43,80,84,66,103});
		try {
			return Klm.rtir(ජजी(जी), ජaේz0());
		} catch (Exception e) {
			return null;
		}
	}
	
	public static String ජaේz03() {
		//"hrF-11Ab617A"
		//senha final lib
		String जी = new String(new byte[] {81,68,119,120,75,117,118,51,56,83,81,121,78,47,98,81,102,68,70,97,54,47,107,83,111,112,69,52,48,74,82,48,106,88,55,114,72,71,100,53,81,68,97,79,102,84,71,76,114,47,90,108,88,50,76,114,122,88,51,104,108,81,97,56});
		try {
			return Klm.rtir(ජजी(जी), ජaේz01());
		} catch (Exception e) {
			return null;
		}
	}

	public static String ජजlी0() {
		try {
			return ජaේ03();
		} catch (Exception e) {
			return null;
		}
	}
	
	public static String ජजlी00() {
		try {
			return ජaේz03();
		} catch (Exception e) {
			return null;
		}
	}

	public static String ජजlी1(String ජजी4) {
		if (ජේтыजीش().equals(ජේ00())) {
			try {
				return Klm.rtir(ජजी4, ජजlी0());
			} catch (Exception e) {
				return null;
			}
		} else {
			return null;
		}
	}

	public static String ජजlी12(String ජजी4) {
		try {
			return Klm.rtir(ජजी4, ජजlी0());
		} catch (Exception e) {
			return null;
		}
	}
	
	public static String ජजlी13(String ජजी4) {
		try {
			return Klm.rtir(ජजी4, ජजlी00());
		} catch (Exception e) {
			return null;
		}
	}

	public static String ජजlी1v(String ජजी4) {
		if (ජේтыजीش().equals(ජේ00())) {
			try {
				return Klm.rtir(ජजी(ජजी4), ජजी(ජजlी0()));
			} catch (Exception e) {
				return null;
			}
		} else {
			return null;
		}
	}

}
