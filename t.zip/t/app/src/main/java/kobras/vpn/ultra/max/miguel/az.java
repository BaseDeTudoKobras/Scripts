package kobras.vpn.ultra.max.miguel;

public class az
{
    static {System.loadLibrary(a.ජේ114());}
	
	static native String a1();
    public static String ජේ1() {
		//"✅  "
        String जी = a1();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a2();
	public static String ජේ2() {
		//"TLS"
        String जी = a2();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a3();
	public static String ජේ3() {
		//"127.0.0.1"
        String जी = a3();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a4();
	public static String ජේ4() {
		//"files"
        String जी = a4();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a5();
	public static String ජේ5() {
		//"TvTv"
        String जी = a5();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a6();
	public static String ජේ6() {
		//"VtVt"
        String जी = a6();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a7();
	public static String ජේ7() {
		//":"
        String जी = a7();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a8();
	public static String ජේ8() {
		//"sock_path"
        String जी = a8();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a9();
	public static String ජේ9() {
		//"8.8.8.8"
        String जी = a9();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a10();
	public static String ජේ10() {
		//"8.8.4.4"
        String जी = a10();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a11();
	public static String ජේ11() {
		//"-kobras-1"
        String जी = a11();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a12();
	public static String ජේ12() {
		//"fk Finaliza Thread"
        String जी = a12();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a13();
	public static String ජේ13() {
		//"#-MAIN-#"
        String जी = a13();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a14();
	public static String ජේ14() {
		//"#-SERVER_CONFIG-#"
        String जी = a14();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a15();
	public static String ජේ15() {
		//"#-SERVER_RAW-#"
        String जी = a15();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a16();
	public static String ජේ16() {
		//"#-SERVER_AFF-#"
        String जी = a16();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a17();
	public static String ජේ17() {
		//"#-SUB-#"
        String जी = a17();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a18();
	public static String ජේ18() {
		//"#-SETTING-#"
        String जी = a18();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a19();
	public static String ජේ19() {
		//"#-SELECTED_SERVER-#"
        String जी = a19();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a20();
	public static String ජේ20() {
		//"#-ANG_CONFIGS-#"
        String जी = a20();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a21();
	public static String ජේ21() {
		//"O sistema está verificando se tem alguma atualização disponível.<br></br><br></br>AGUARDE..."
        String जी = a21();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a22();
	public static String ජේ22() {
		//"VERIFICAÇÃO CONCLUÍDA"
        String जी = a22();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a23();
	public static String ජේ23() {
		//"CARREGANDO UM ANÚNCIO...<br></br><br></br>Aguarde ser carregado..."
        String जी = a23();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a24();
	public static String ජේ24() {
		//"OK"
        String जी = a24();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a25();
	public static String ජේ25() {
		//"android.resource://kobras.f15.vpn.miguel/drawable/video1"
        String जी = a25();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a26();
	public static String ජේ26() {
		//"android.resource://kobras.f15.vpn.miguel/drawable/video2"
        String जी = a26();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a27();
	public static String ජේ27() {
		//"android.resource://kobras.f15.vpn.miguel/drawable/video3"
        String जी = a27();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a28();
	public static String ජේ28() {
		//"CARREGANDO..."
        String जी = a28();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a29();
	public static String ජේ29() {
		//"translationX"
        String जी = a29();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a30();
	public static String ජේ30() {
		//"rotation"
        String जी = a30();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a31();
	public static String ජේ31() {
		//"BAIXAR AGORA"
        String जी = a31();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a32();
	public static String ජේ32() {
		//"alpha"
        String जी = a32();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a33();
	public static String ජේ33() {
		//"CANCELAR"
        String जी = a33();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a34();
	public static String ජේ34() {
		//"? ? ? ?"
        String जी = a34();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a35();
	public static String ජේ35() {
		//"! VERIFICAÇÃO CANCELADA !"
        String जी = a35();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a36();
	public static String ජේ36() {
		//"VERIFICANDO A CONEXÃO..."
        String जी = a36();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a37();
	public static String ජේ37() {
		//"<font color='black'>INTERNET OK ✓</font>"
        String जी = a37();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a38();
	public static String ජේ38() {
		//"! INTERNET FALHOU !"
        String जी = a38();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a39();
	public static String ජේ39() {
		//"NOTIFICAÇÃO NÃO SUPORTADA NESSE APARELHO !"
        String जी = a39();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a40();
	public static String ජේ40() {
		//"DOWNLOAD DAS LISTAS"
        String जी = a40();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a41();
	public static String ජේ41() {
		//"BAIXANDO AS LISTAS...<br></br><br></br>Aguarde o processo terminar !"
        String जी = a41();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a42();
	public static String ජේ42() {
		//"CONFIGURAÇÃO INICIAL"
        String जी = a42();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a43();
	public static String ජේ43() {
		//"Por favor baixe as listas de servidores e configurações,<br></br><br></br>Precisa de internet para fazer o download das listas !"
        String जी = a43();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a44();
	public static String ජේ44() {
		//"<b>! ! ! !</b>"
        String जी = a44();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a45();
	public static String ජේ45() {
		//"SELECIONE UM SERVIDOR"
        String जी = a45();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a46();
	public static String ජේ46() {
		//"SELECIONE UMA CONFIGURAÇÃO"
        String जी = a46();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
	static native String a47();
	public static String ජේ47() {
		//":  "
        String जी = a47();
        try {
			return a.ජजlी12(a.ජजी(जी));
		} catch (Exception e) {
			return null;
		}
    }
    
}
