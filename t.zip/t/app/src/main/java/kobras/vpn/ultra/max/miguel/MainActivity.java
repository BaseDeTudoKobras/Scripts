package kobras.vpn.ultra.max.miguel;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity
{
    public static Context mContext;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
		mContext = this;
        super.onCreate(savedInstanceState);
		
        TextView  tv = new TextView(this);
        tv.setText(a.ජේ0i());
        setContentView(tv);
    }
}
