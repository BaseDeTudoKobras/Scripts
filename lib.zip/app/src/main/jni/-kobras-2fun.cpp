#include <jni.h>
#include <string>

#include <dirent.h>

static jboolean check = JNI_FALSE;

const static char *CLASS_NAME_NATIVECONTEXT = "kobras/salto/dos/lider/MainActivity";
const static char *METHOD_T_CONTEXT = "mContext";
const static char *METHOD_GETCONTEXT = "()Landroid/content/Context;";

extern "C"
{
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_li01(JNIEnv* env)
	{
		//c/c/b/a/c/a/a
		return env->NewStringUTF("9Gaeyk5xIbmv+ghBC7RBhwKoN64WpIgPceDtOXkjFaI=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_li02(JNIEnv* env)
	{
		//http://localhost/
		return env->NewStringUTF("4mziOHvXC+2AHWxvg8j5pjKM18Y7bcCBFjFTwRNpiMRUVd4aE9uYT2Z9B6DaKLB0");
	}
}

static jboolean chula(JNIEnv *env)
{
	jclass activity = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(activity, METHOD_T_CONTEXT, METHOD_GETCONTEXT);									 
    jobject context = env->CallStaticObjectMethod(activity, midGetContext);
	
	jfieldID a_str2r = env->GetFieldID(activity,"ජේ3rs", "Ljava/lang/String;");
    jstring a2r = (jstring) env->GetObjectField(context, a_str2r);
	jfieldID a_str2s = env->GetFieldID(activity,"ජේ3ss", "Ljava/lang/String;");
    jstring a2s = (jstring) env->GetObjectField(context, a_str2s);
	jfieldID a_str2t = env->GetFieldID(activity,"ජේ3ts", "Ljava/lang/String;");
    jstring a2t = (jstring) env->GetObjectField(context, a_str2t);
	
	jclass contextClass = env->GetObjectClass(context);
    jmethodID mk1 = env->GetMethodID(contextClass, env->GetStringUTFChars(a2r, NULL), env->GetStringUTFChars(a2s, NULL));
    jobject mk2 = env->CallObjectMethod(context, mk1);
    jclass mk3 = env->GetObjectClass(mk2);
    jfieldID mk4 = env->GetFieldID(mk3, env->GetStringUTFChars(a2t, NULL), "Ljava/lang/String;");
    jstring mk5 = (jstring)env->GetObjectField(mk2, mk4);
	
	return mk5 == NULL;
}

static jboolean chula2(JNIEnv *env)
{
	jclass activity = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(activity, METHOD_T_CONTEXT, METHOD_GETCONTEXT);									 
    jobject context = env->CallStaticObjectMethod(activity, midGetContext);
	
	jfieldID a_str2r = env->GetFieldID(activity,"ජේ3rs", "Ljava/lang/String;");
    jstring a2r = (jstring) env->GetObjectField(context, a_str2r);
	jfieldID a_str2s = env->GetFieldID(activity,"ජේ3ss", "Ljava/lang/String;");
    jstring a2s = (jstring) env->GetObjectField(context, a_str2s);
	jfieldID a_str2t = env->GetFieldID(activity,"ජේ32ts", "Ljava/lang/String;");
    jstring a2t = (jstring) env->GetObjectField(context, a_str2t);
	
	jclass contextClass = env->GetObjectClass(context);
    jmethodID mk1 = env->GetMethodID(contextClass, env->GetStringUTFChars(a2r, NULL), env->GetStringUTFChars(a2s, NULL));
    jobject mk2 = env->CallObjectMethod(context, mk1);
    jclass mk3 = env->GetObjectClass(mk2);
    jfieldID mk4 = env->GetFieldID(mk3, env->GetStringUTFChars(a2t, NULL), "Ljava/lang/String;");
    jstring mk5 = (jstring)env->GetObjectField(mk2, mk4);
	
	struct dirent *d;
    DIR *dr;
	dr = opendir(env->GetStringUTFChars(mk5, NULL));
	int se = 0;
	
	jfieldID a_tp1 = env->GetFieldID(activity,"ජේtp1", "Ljava/lang/String;");
    jstring tp1 = (jstring) env->GetObjectField(context, a_tp1);
	jfieldID a_tp2 = env->GetFieldID(activity,"ජේtp2", "Ljava/lang/String;");
    jstring tp2 = (jstring) env->GetObjectField(context, a_tp2);
	jfieldID a_tp3 = env->GetFieldID(activity,"ජේtp3", "Ljava/lang/String;");
    jstring tp3 = (jstring) env->GetObjectField(context, a_tp3);
	jfieldID a_tp4 = env->GetFieldID(activity,"ජේtp4", "Ljava/lang/String;");
    jstring tp4 = (jstring) env->GetObjectField(context, a_tp4);
	jfieldID a_tp5 = env->GetFieldID(activity,"ජේtp5", "Ljava/lang/String;");
    jstring tp5 = (jstring) env->GetObjectField(context, a_tp5);
	jfieldID a_tp6 = env->GetFieldID(activity,"ජේtp6", "Ljava/lang/String;");
    jstring tp6 = (jstring) env->GetObjectField(context, a_tp6);
	
	jfieldID a_tp8 = env->GetFieldID(activity,"ජේtp8", "Ljava/lang/String;");
    jstring tp8 = (jstring) env->GetObjectField(context, a_tp8);
	
	
	const char *kA1 = env->GetStringUTFChars(tp1, NULL);
    const char *kA2 = env->GetStringUTFChars(tp2, NULL);
	const char *kA3 = env->GetStringUTFChars(tp3, NULL);
	const char *kA4 = env->GetStringUTFChars(tp4, NULL);
	const char *kA5 = env->GetStringUTFChars(tp5, NULL);
	const char *kA6 = env->GetStringUTFChars(tp6, NULL);

	const char *kA8 = env->GetStringUTFChars(tp8, NULL);

    while ((d = readdir(dr)) != NULL)
    {
    	if (strcmp(kA1, d->d_name) != 0 && strcmp(kA2, d->d_name) != 0)
		{
			if (strcmp(kA3, d->d_name) == 0 || strcmp(kA4, d->d_name) == 0 || strcmp(kA5, d->d_name) == 0)
			{
				return false;
			}
			if (strcmp(kA6, d->d_name) != 0 && strcmp(kA8, d->d_name) != 0)
			{
				return false;
			}
        	se++;
		}
    }
    closedir(dr);
	return se == 2;
}
	
const static int Unp(const char *source, char *dest, int sourceLen)
{
    short i;
    char highByte, lowByte;

    for (i = 0; i < sourceLen; i++)
	{
        highByte = source[i] >> 4;
        lowByte = source[i] & 0x0f;
        highByte += 0x30;

        if (highByte > 0x39)
		{
            dest[i * 2] = highByte + 0x07;
        } else
		{
            dest[i * 2] = highByte;
        }

        lowByte += 0x30;
        if (lowByte > 0x39)
		{
            dest[i * 2 + 1] = lowByte + 0x07;
        } else
		{
            dest[i * 2 + 1] = lowByte;
        }
    }
	
	return 0;
}

const static jstring ToM(JNIEnv *env, jobject context, jbyteArray source)
{
	jclass activity = env->FindClass(CLASS_NAME_NATIVECONTEXT);
	jfieldID a_str = env->GetFieldID(activity,"ජේ10s", "Ljava/lang/String;");
    jstring a1 = (jstring) env->GetObjectField(context, a_str);
	jfieldID a_str2 = env->GetFieldID(activity,"ජේ11s", "Ljava/lang/String;");
    jstring a2 = (jstring) env->GetObjectField(context, a_str2);
	jfieldID a_str3 = env->GetFieldID(activity,"ජේ12s", "Ljava/lang/String;");
    jstring a3 = (jstring) env->GetObjectField(context, a_str3);
	jfieldID a_str4 = env->GetFieldID(activity,"ජේ13s", "Ljava/lang/String;");
    jstring a4 = (jstring) env->GetObjectField(context, a_str4);
	jfieldID a_str5 = env->GetFieldID(activity,"ජේ14s", "Ljava/lang/String;");
    jstring a5 = (jstring) env->GetObjectField(context, a_str5);
	jfieldID a_str6 = env->GetFieldID(activity,"ජේ15s", "Ljava/lang/String;");
    jstring a6 = (jstring) env->GetObjectField(context, a_str6);
	jfieldID a_str7 = env->GetFieldID(activity,"ජේ16s", "Ljava/lang/String;");
    jstring a7 = (jstring) env->GetObjectField(context, a_str7);
	jfieldID a_str8 = env->GetFieldID(activity,"ජේ17s", "Ljava/lang/String;");
    jstring a8 = (jstring) env->GetObjectField(context, a_str8);
	
    jclass classMessageDigest = env->FindClass(env->GetStringUTFChars(a1, NULL));
    jmethodID midGetInstance = env->GetStaticMethodID(classMessageDigest, env->GetStringUTFChars(a2, NULL), env->GetStringUTFChars(a3, NULL));

    jobject objMessageDigest = env->CallStaticObjectMethod(classMessageDigest, midGetInstance, env->NewStringUTF(env->GetStringUTFChars(a4, NULL)));

    jmethodID midUpdate = env->GetMethodID(classMessageDigest, env->GetStringUTFChars(a5, NULL), env->GetStringUTFChars(a6, NULL));
    env->CallVoidMethod(objMessageDigest, midUpdate, source);
    jmethodID midDigest = env->GetMethodID(classMessageDigest, env->GetStringUTFChars(a7, NULL), env->GetStringUTFChars(a8, NULL));
    jbyteArray objArraySign = (jbyteArray) env->CallObjectMethod(objMessageDigest, midDigest);
    jsize intArrayLength = env->GetArrayLength(objArraySign);
    jbyte *byte_array_elements = env->GetByteArrayElements(objArraySign, NULL);
    size_t length = (size_t) intArrayLength * 2 + 1;
    char *char_result = (char *) malloc(length);
    memset(char_result, 0, length);
    Unp((const char *) byte_array_elements, char_result, intArrayLength);
    *(char_result + intArrayLength * 2) = '\0';

    jstring stringResult = env->NewStringUTF(char_result);
    env->ReleaseByteArrayElements(objArraySign, byte_array_elements, JNI_ABORT);
    free(char_result);

    return stringResult;
}

const static jstring jpd(JNIEnv *env, jobject context) {
    jclass cls = env->GetObjectClass(context);
	jclass activity = env->FindClass(CLASS_NAME_NATIVECONTEXT);
	jfieldID a_str = env->GetFieldID(activity,"ජේ2s", "Ljava/lang/String;");
    jstring a1 = (jstring) env->GetObjectField(context, a_str);
	jfieldID a_str2 = env->GetFieldID(activity,"ජේ3s", "Ljava/lang/String;");
    jstring a2 = (jstring) env->GetObjectField(context, a_str2);
	jfieldID a_str3 = env->GetFieldID(activity,"ජේ4s", "Ljava/lang/String;");
    jstring a3 = (jstring) env->GetObjectField(context, a_str3);
	jfieldID a_str4 = env->GetFieldID(activity,"ජේ5s", "Ljava/lang/String;");
    jstring a4 = (jstring) env->GetObjectField(context, a_str4);
	jfieldID a_str5 = env->GetFieldID(activity,"ජේ6s", "Ljava/lang/String;");
    jstring a5 = (jstring) env->GetObjectField(context, a_str5);
	jfieldID a_str6 = env->GetFieldID(activity,"ජේ7s", "Ljava/lang/String;");
    jstring a6 = (jstring) env->GetObjectField(context, a_str6);
	jfieldID a_str7 = env->GetFieldID(activity,"ජේ8s", "Ljava/lang/String;");
    jstring a7 = (jstring) env->GetObjectField(context, a_str7);
	jfieldID a_str8 = env->GetFieldID(activity,"ජේ9s", "Ljava/lang/String;");
    jstring a8 = (jstring) env->GetObjectField(context, a_str8);
	
	jfieldID a_str9 = env->GetFieldID(activity,"ජේ17s", "Ljava/lang/String;");
    jstring a9 = (jstring) env->GetObjectField(context, a_str9);
	
	jfieldID a_str10 = env->GetFieldID(activity,"ජේai2", "Ljava/lang/String;");
    jstring a10 = (jstring) env->GetObjectField(context, a_str10);
	
    jmethodID mid = env->GetMethodID(cls, env->GetStringUTFChars(a1, NULL), env->GetStringUTFChars(a2, NULL));

    jobject pm = env->CallObjectMethod(context, mid);
    mid = env->GetMethodID(cls, env->GetStringUTFChars(a3, NULL), env->GetStringUTFChars(a10, NULL));
    jstring dA5 = (jstring) env->CallObjectMethod(context, mid);
    cls = env->GetObjectClass(pm);
    mid = env->GetMethodID(cls, env->GetStringUTFChars(a4, NULL), env->GetStringUTFChars(a5, NULL));
						   
    jobject dA4 = env->CallObjectMethod(pm, mid, dA5, 0x40); //GET_SIGNATURES = 64;
    cls = env->GetObjectClass(dA4);
    jfieldID fid = env->GetFieldID(cls, env->GetStringUTFChars(a6, NULL), env->GetStringUTFChars(a7, NULL));
    jobjectArray dA3 = (jobjectArray) env->GetObjectField(dA4, fid);
    jobject dA2 = env->GetObjectArrayElement(dA3, 0);
    cls = env->GetObjectClass(dA2);
    mid = env->GetMethodID(cls, env->GetStringUTFChars(a8, NULL), env->GetStringUTFChars(a9, NULL));
    jbyteArray dA1 = (jbyteArray) env->CallObjectMethod(dA2, mid);

    return ToM(env, context, dA1);
}

const static jboolean jpa(JNIEnv *env, jobject context) {

    jstring kB1 = jpd(env, context);
	
	jclass activity2 = env->FindClass(CLASS_NAME_NATIVECONTEXT);
	jfieldID a_str = env->GetFieldID(activity2,"ජේ1s", "Ljava/lang/String;");
    jstring kB2 = (jstring) env->GetObjectField(context, a_str);
	
    const char *kA1 = env->GetStringUTFChars(kB1, NULL);
    const char *kA2 = env->GetStringUTFChars(kB2, NULL);
    
    jboolean result = JNI_FALSE;
	
    if (kA1 != NULL && kA2 != NULL)
	{
        if (strcmp(kA1, kA2) == 0)
		{
            result = JNI_TRUE;
        }
    }
   
    return result;
}
 
 
const static jboolean jpb(JNIEnv *env)
{
    jclass classNativ = env->FindClass(CLASS_NAME_NATIVECONTEXT);
    jmethodID midGetContext = env->GetStaticMethodID(classNativ, METHOD_T_CONTEXT, METHOD_GETCONTEXT);
    jobject appContext2 = env->CallStaticObjectMethod(classNativ, midGetContext);
	
    if (appContext2 != NULL)
	{
        jboolean jpc = jpa(env, appContext2);
    	return jpc;
    }
    return JNI_FALSE;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    if (vm->GetEnv((void **) (&env), JNI_VERSION_1_6) != JNI_OK)
	{
        return -1;
    }
    if (!jpb(env))
	{
        return -1;
    }
	if (chula(env))
	{
		if (!chula2(env))
		{
			return -1;
		}
		else
		{
			check = JNI_TRUE;
		}
	}
	else
	{
		return -1;
	}
	
	
    return JNI_VERSION_1_6;
}
