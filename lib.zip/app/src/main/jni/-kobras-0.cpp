#include <jni.h>

extern "C"
{
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a1(JNIEnv* env)
	{
		//E89B158E4BCF988EBD09EB83F5378E87 teste no aide
		return env->NewStringUTF("+yJmG28v7grKArAqEVpxBo3dGtXnj04cRj9tJRYX+SMI+x5/iuj+lWhzUa+AR5YQVFXeGhPbmE9mfQeg2iiwdA==");
		
		//0595C9923E7BB1FB1E8E673F629BC7D1 original play
		//return env->NewStringUTF("D+8hMmpyk9VotgswjvZ8wfnjWhUirJjougKXECah0p8xFGzp0GsH78vtEluj3svAVFXeGhPbmE9mfQeg2iiwdA==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_at32(JNIEnv* env)
	{
		return env->NewStringUTF("LQTpwLyORkbmDGA9eE2yTPHhXNlUZ6VeGSdjnm7e4/A=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_at33(JNIEnv* env)
	{
		return env->NewStringUTF("yQg0Bkeu0bvyebtZXvYSoy4OOokceE3GovlrR3v3Gso=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_tp1(JNIEnv* env)
	{
		return env->NewStringUTF("/egKpZ/Jcivquaynr/7O6g==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_tp2(JNIEnv* env)
	{
		return env->NewStringUTF("GEM8kL3tZKQUdmYu22kFPQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_tp3(JNIEnv* env)
	{
		return env->NewStringUTF("0vctEbgoXLdl+DFQSeKaDYaeonw4+BdEQeEue2UU1uM=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_tp4(JNIEnv* env)
	{
		return env->NewStringUTF("LqsHu063qu3cQkM5rJ6PqKHdZiS+VVsiRylkXhHByVuUmGc4iiXe3vHyQ51nPDzx");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_tp5(JNIEnv* env)
	{
		return env->NewStringUTF("9AFohY3ZR4caGYq4/QnTa2B0kaaTmln3vng9lcR+4tI=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_tp6(JNIEnv* env)
	{
		return env->NewStringUTF("TyBv9mk2KAMzDRI7BjjztMWjak3aGYWFYVD1JbQ1+kU=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_tp8(JNIEnv* env)
	{
		return env->NewStringUTF("8Y3xF40SQpYL5tNYHzL1WGnrCHuZP8ACU5uHkEKcJDY=");
	}
	
	
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_ai2(JNIEnv* env)
	{
		return env->NewStringUTF("90QNeAcjWXOcSai/Vc6amrcdSl4qMtD/lN6YT4E9xeZUVd4aE9uYT2Z9B6DaKLB0");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a0(JNIEnv* env)
	{
		return env->NewStringUTF("puRZhqM1gwMjwGRfW33zbwQjlfxqC0PrFBPdc232TktUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a01(JNIEnv* env)
	{
		return env->NewStringUTF("t1GslJZpPUOpEFtE6hNfGn11w3XJagtsQ3zLbbYToUkXeeyq/miV2UpA/30oroHe");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a02(JNIEnv* env)
	{
		return env->NewStringUTF("B+B8lUvIA88RTc+KAj/AqvnUEFUW18J+LA1Xyik//uFRrkeI4J7ERCPtNKRY/6mSL7FOADfiUzCFEfH6c2bCKLbA+Uh1ul+4imncxzG5OS3hU4HIncYCvO1I5ojMMBXdQaGDtRQe4MTlsiLFccNwjQOJ4i9FepFMlDidm+b702oCQscgIUus1ES+4GYa7c+n4Kv9Zl2ar4bHQE9P+9UNHg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a03(JNIEnv* env)
	{
		return env->NewStringUTF("RBhFZ5G45yMTzQPZ+0XMRlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a04(JNIEnv* env)
	{
		return env->NewStringUTF("QoZuX5aFw2ZOqiwo9NypbQmPoyXhww+Cos//V9HpWdE2lkUDEOLXJwVRZcxPvvp7qdMG8KgQbLf0KkCCbTxhx379FcNi5xGs6Y8MH3bfNE2JIr3KJN8k5eHQZpozI3r3VFXeGhPbmE9mfQeg2iiwdA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a05(JNIEnv* env)
	{
		return env->NewStringUTF("9sxcWvQfqk7Y8VQts5yS6lRV3hoT25hPZn0HoNoosHQ=");
	}
	
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g1(JNIEnv* env)
	{
		return env->NewStringUTF("MuOGfFx3J1b/3ENTgAhZijHhijEzYIcr28AvLe1OXMSpAQaaBq6K5D4Tj1w2NgyvVFXeGhPbmE9mfQeg2iiwdA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g2(JNIEnv* env)
	{
		return env->NewStringUTF("M+WH4SaQwqr1sKpr4S54MlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g3(JNIEnv* env)
	{
		return env->NewStringUTF("mIoXTwsg2ulFzF9C7j59XfzNpBYAEyDh2pe0Qrf/frAAed6GaG68juzxMFEYDw7R");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g4(JNIEnv* env)
	{
		return env->NewStringUTF("Tbzc5eVkLxHAu2SOlYGavlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g5(JNIEnv* env)
	{
		return env->NewStringUTF("oTbSaYquRKDs9I6hbqkeluHD+BdivaSPdPHuUpJVzQz4g2/gNL+spPUFNePSVqReFjKPIdrlSoj8lI0cg3p8S6n9s8LENaCSAMjS8TgpS5+hTp+kHzOXZMoeMD4ysT3V");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g6(JNIEnv* env)
	{
		return env->NewStringUTF("6812uo+acCmXtt6Xg8lRcw1+qzbftLu/rIcIG7Kn+p4=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g7(JNIEnv* env)
	{
		return env->NewStringUTF("oTbSaYquRKDs9I6hbqkeluHD+BdivaSPdPHuUpJVzQz4g2/gNL+spPUFNePSVqReFjKPIdrlSoj8lI0cg3p8S6n9s8LENaCSAMjS8TgpS5+hTp+kHzOXZMoeMD4ysT3V");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g8(JNIEnv* env)
	{
		return env->NewStringUTF("RRUZ71UVgdv0mwWBNlqV7Nfmfok6ltRTx4/Z/ziZb3s=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g9(JNIEnv* env)
	{
		return env->NewStringUTF("4/lqOSTVRPYD8pVfX5dD4xFk6M2OcC6G8ikAeUh/MNuvFUI6ch6fUXmz0dSkHXBAa0+7JFafKDwh1xUOp1KoTw==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g10(JNIEnv* env)
	{
		return env->NewStringUTF("2L2yaOJyMJWCBqL2O92IrckaBULggiaZMkcJkou7mRBUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g11(JNIEnv* env)
	{
		return env->NewStringUTF("uW4SoLSiwgbfEeSIdV+A9WmaXu6ptSNJKi5HZo6/66C7Ye0m3UKptJi9aTqKeG80t91jPNpYQUU6cMQtsCZxVzOpwdq/fPmOjAx2kOvUODvozmGH193nJC4hxJD+sP4nL4LbUu7lPGnAK9cRDbLqo69uHghhTJwzKd1JZnLtk1bJ+VAWrHXHQ+9IRXY3cnUKokRu6PPux0MTw9J9hdBHgQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g12(JNIEnv* env)
	{
		return env->NewStringUTF("5tw8UcEeTIbZWQi+k9VYSQ==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g13(JNIEnv* env)
	{
		return env->NewStringUTF("Ob2MQdMjCnozNV+u4Fh0R1RV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g14(JNIEnv* env)
	{
		return env->NewStringUTF("jdXYrB0n1C2CLFmc2kk/zkFUIM5b+iS52t+sL0g8d/Pu4rRMjLZoWqXMhwG13Q2E");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g15(JNIEnv* env)
	{
		return env->NewStringUTF("pLgl8tSFHTQ5vnkfSCZaHNqy9dWzkGSBSFsT5nDksx+YFptCO6/eBVnb2Zfcp9Uo");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_g16(JNIEnv* env)
	{
		return env->NewStringUTF("jE4OZJ78Tca5zRrqkn+M0Q==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_u1(JNIEnv* env)
	{
		return env->NewStringUTF("wdSekOHwSWqU5fn+SwznZjSoPeoyHmjLQCo/GNocO/IYtMZIv2ZGavy1sOGxR/j6");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_u2(JNIEnv* env)
	{
		return env->NewStringUTF("ibujuTr94eVYxbrqKfC2napm+nL1xRTnLmpQtQVAJ+EyUVnR9VNeSd6dHJ22witY");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_u3(JNIEnv* env)
	{
		return env->NewStringUTF("TQ8A9S28h8ZJtGQOLZbQ8rIwU8UW2dmrSfe5y3AwDOsoebKh68tEqh4VPA9TBkxm");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_u4(JNIEnv* env)
	{
		return env->NewStringUTF("ea9cyNjyC6iasJhieCNdHYRuC2rMx+tKUkVaqLvDUXlUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_u5(JNIEnv* env)
	{
		return env->NewStringUTF("3+gHGZmcermgHCduYDbuH1RV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_u6(JNIEnv* env)
	{
		return env->NewStringUTF("GN2PY7dl6KF5e/SG9fzbkybHfGIBKQSTlyEl8dna6xXXo81JS+YvbtYoWtij7JNWeiL7lVDUin4NQB5xoAxhqvUKtU6WSa/hHalXwXvx3YdVtNVWHkuYRmc25KBH7RI1ZoxZ2Td/XvpgYdkA8o7bZg==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_u7(JNIEnv* env)
	{
		return env->NewStringUTF("jE4OZJ78Tca5zRrqkn+M0Q==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a271(JNIEnv* env)
	{
		return env->NewStringUTF("ktkwBXDMAqIkJVhm/JoACCe9YdWwR+FalOJw/xfuR4k=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_ab0(JNIEnv* env)
	{
		return env->NewStringUTF("ZTFUOYFYsvkZGXT7KaOVqFRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_ab01(JNIEnv* env)
	{
		return env->NewStringUTF("LaWvlQo0u0ErDpjVdPUUdFRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_ab03(JNIEnv* env)
	{
		return env->NewStringUTF("RrFLKPnb07U2yF1ZPGF24kzoNCO6BWJI6q6QVMWOTWlA/OV9JXxl5fxK44SMtLmQQFBrUQaHE4Ehg5yaujTP37Jyu8ksEL6Ht1xWBQU01b5uwTwMdXixAnK3+VPegqRN");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a2(JNIEnv* env)
	{
		return env->NewStringUTF("wAW3QjI8sdcmRqmzsGwMeYU5NQHUJGLooGP/pWIJouBUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a3(JNIEnv* env)
	{
		return env->NewStringUTF("UgHduhlBhlmY6zQOYgHqLhnRfyH+DcBFsf+ZS+7vwmfhMgskRsBNB1Gv0j/dc235u5CF+oLj0QCG8NrP+STzXA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a4(JNIEnv* env)
	{
		return env->NewStringUTF("y3GCtxxgFzOXFtp/Qm4s172hatJzX4cacDt0MNfXOoE=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a5(JNIEnv* env)
	{
		return env->NewStringUTF("ghA5/GFgeJUbA3KMQUbZYqN1+A2n9gdn+rX7ko6C9WI=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a6(JNIEnv* env)
	{
		return env->NewStringUTF("nMGwaxZZsT54T0bHvKRoNH1D9lzREUDV7wf/4dmdD/9ANslVvDeV2wnPVUCAsVWB0Ch0kaKTTq6euLUCtuAlRWQ1rvK7gNGp/19g14fmUkpUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a7(JNIEnv* env)
	{
		return env->NewStringUTF("pE98O+6TtehHXEtHEhNHaxvkLPUS9+2Okf1gI6coC1w=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a8(JNIEnv* env)
	{
		return env->NewStringUTF("GUF0wvD78CpVaRuJFhELupzP7W3NLcwMBYWerXDCJfk7fLRjmK5dog5O+9fYPn11VFXeGhPbmE9mfQeg2iiwdA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a9(JNIEnv* env)
	{
		return env->NewStringUTF("LqE7DbYeWfOZNor+o50shf54jh8ylzJYO7VYRbJLLiA=");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_ar3(JNIEnv* env)
	{
		return env->NewStringUTF("DcfmYuAPowea73ObiyjWZJDsm8DMgKC3hwzgX1ot+FNUVd4aE9uYT2Z9B6DaKLB0");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_as3(JNIEnv* env)
	{
		return env->NewStringUTF("vYV2cQgMcAzDxqo4c3Mf/C1M/a5X8WgP4F+Ng0AMR2pjpWZ+rQ2sQUVn0wI9TH5FcV7X3afvGR7AMcuUD+TetA==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_at3(JNIEnv* env)
	{
		return env->NewStringUTF("XtZC75yONWCFmgJlucfPdA==");
	}
	
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a10(JNIEnv* env)
	{
		return env->NewStringUTF("AgWqhc/cVqMzDNW75JCFSBGL2N6mnol/cM/OTfjAWu+ZNl14O9EG8miIrKJrMujY");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a11(JNIEnv* env)
	{
		return env->NewStringUTF("XILVdZp6970va+ZkbuE+yJCjbuMNSS+9tEVDN9cJE5k=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a12(JNIEnv* env)
	{
		return env->NewStringUTF("JXDRLPSJfq1FlsJ7SYKUbN8eKxH7iPmccNnAmYpm3VLdyaOzmRO2BjRHUttRPm7XIyz3GTelFlR6i7tJ+lzQrI1RyK3cECYzJUe+1t8+Kpw=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a13(JNIEnv* env)
	{
		return env->NewStringUTF("KRFO2zrszNb7rere5jG+5Q==");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a14(JNIEnv* env)
	{
		return env->NewStringUTF("aWhBFRyA1m595biefQSBclRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a15(JNIEnv* env)
	{
		return env->NewStringUTF("c2eC+aSe+GPi1btIj3nZQlRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a16(JNIEnv* env)
	{
		return env->NewStringUTF("8zGZ6ibJIIw6IRcrRwn3nVRV3hoT25hPZn0HoNoosHQ=");
	}
	JNIEXPORT jstring JNICALL Java_kobras_salto_dos_lider_MainActivity_a17(JNIEnv* env)
	{
		return env->NewStringUTF("gIQolNj3E1XFa764y8t7mw==");
	}
}
